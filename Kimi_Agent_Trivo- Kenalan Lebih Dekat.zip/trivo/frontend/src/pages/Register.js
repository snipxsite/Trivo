import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import styled from 'styled-components';
import { useAuth } from '../context/AuthContext';

const Container = styled.div`
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  padding: 20px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
`;

const LogoContainer = styled.div`
  text-align: center;
  margin-bottom: 30px;
`;

const Logo = styled.div`
  width: 80px;
  height: 80px;
  background: linear-gradient(135deg, #FF6B6B 0%, #FF8E53 100%);
  border-radius: 25px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 40px;
  margin: 0 auto 15px;
  box-shadow: 0 10px 30px rgba(255, 107, 107, 0.3);
`;

const Title = styled.h1`
  font-size: 28px;
  font-weight: 700;
  color: white;
  margin-bottom: 8px;
`;

const Subtitle = styled.p`
  font-size: 14px;
  color: rgba(255, 255, 255, 0.8);
`;

const Form = styled.form`
  width: 100%;
  max-width: 350px;
  background: white;
  padding: 25px;
  border-radius: 20px;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
`;

const InputGroup = styled.div`
  margin-bottom: 15px;
`;

const Label = styled.label`
  display: block;
  font-size: 13px;
  font-weight: 500;
  color: #333;
  margin-bottom: 6px;
`;

const Input = styled.input`
  width: 100%;
  padding: 12px 14px;
  border: 2px solid #e0e0e0;
  border-radius: 10px;
  font-size: 14px;
  transition: all 0.3s ease;
  
  &:focus {
    outline: none;
    border-color: #FF6B6B;
  }
  
  &::placeholder {
    color: #aaa;
  }
`;

const Select = styled.select`
  width: 100%;
  padding: 12px 14px;
  border: 2px solid #e0e0e0;
  border-radius: 10px;
  font-size: 14px;
  transition: all 0.3s ease;
  background: white;
  
  &:focus {
    outline: none;
    border-color: #FF6B6B;
  }
`;

const Row = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 10px;
`;

const Button = styled.button`
  width: 100%;
  padding: 14px;
  background: linear-gradient(135deg, #FF6B6B 0%, #FF8E53 100%);
  color: white;
  border: none;
  border-radius: 10px;
  font-size: 16px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
  margin-top: 10px;
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 20px rgba(255, 107, 107, 0.4);
  }
  
  &:disabled {
    opacity: 0.7;
    cursor: not-allowed;
    transform: none;
  }
`;

const ErrorMessage = styled.div`
  background: #ffebee;
  color: #c62828;
  padding: 10px;
  border-radius: 8px;
  margin-bottom: 15px;
  font-size: 13px;
  text-align: center;
`;

const LinkText = styled.p`
  text-align: center;
  margin-top: 15px;
  font-size: 13px;
  color: #666;
`;

const StyledLink = styled(Link)`
  color: #FF6B6B;
  font-weight: 600;
  text-decoration: none;
  
  &:hover {
    text-decoration: underline;
  }
`;

const TermsText = styled.p`
  font-size: 11px;
  color: #999;
  text-align: center;
  margin-top: 15px;
  line-height: 1.5;
`;

const Register = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    age: '',
    gender: '',
    city: ''
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { register } = useAuth();
  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    const result = await register({
      ...formData,
      age: parseInt(formData.age)
    });
    
    if (result.success) {
      navigate('/');
    } else {
      setError(result.message);
    }
    
    setLoading(false);
  };

  return (
    <Container>
      <LogoContainer>
        <Logo>💝</Logo>
        <Title>Buat Akun</Title>
        <Subtitle>Bergabung dengan Trivo sekarang</Subtitle>
      </LogoContainer>

      <Form onSubmit={handleSubmit}>
        {error && <ErrorMessage>{error}</ErrorMessage>}
        
        <InputGroup>
          <Label>Nama Lengkap</Label>
          <Input
            type="text"
            name="name"
            placeholder="Masukkan nama"
            value={formData.name}
            onChange={handleChange}
            required
          />
        </InputGroup>

        <InputGroup>
          <Label>Email</Label>
          <Input
            type="email"
            name="email"
            placeholder="Masukkan email"
            value={formData.email}
            onChange={handleChange}
            required
          />
        </InputGroup>

        <InputGroup>
          <Label>Password</Label>
          <Input
            type="password"
            name="password"
            placeholder="Minimal 6 karakter"
            value={formData.password}
            onChange={handleChange}
            required
            minLength={6}
          />
        </InputGroup>

        <Row>
          <InputGroup>
            <Label>Umur</Label>
            <Input
              type="number"
              name="age"
              placeholder="18+"
              value={formData.age}
              onChange={handleChange}
              required
              min={18}
              max={100}
            />
          </InputGroup>

          <InputGroup>
            <Label>Gender</Label>
            <Select
              name="gender"
              value={formData.gender}
              onChange={handleChange}
              required
            >
              <option value="">Pilih</option>
              <option value="male">Laki-laki</option>
              <option value="female">Perempuan</option>
              <option value="other">Lainnya</option>
              <option value="prefer_not_to_say">Rahasia</option>
            </Select>
          </InputGroup>
        </Row>

        <InputGroup>
          <Label>Kota</Label>
          <Input
            type="text"
            name="city"
            placeholder="Masukkan kota"
            value={formData.city}
            onChange={handleChange}
          />
        </InputGroup>

        <Button type="submit" disabled={loading}>
          {loading ? 'Loading...' : 'Daftar'}
        </Button>

        <TermsText>
          Dengan mendaftar, Anda menyetujui{' '}
          <StyledLink to="/terms">Syarat & Ketentuan</StyledLink> dan{' '}
          <StyledLink to="/privacy">Kebijakan Privasi</StyledLink> kami.
        </TermsText>

        <LinkText>
          Sudah punya akun? <StyledLink to="/login">Masuk</StyledLink>
        </LinkText>
      </Form>
    </Container>
  );
};

export default Register;
