import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import styled from 'styled-components';
import axios from 'axios';

const Container = styled.div`
  padding: 16px;
`;

const Header = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
`;

const Title = styled.h1`
  font-size: 24px;
  font-weight: 700;
  color: white;
`;

const AddButton = styled.button`
  background: white;
  border: none;
  width: 45px;
  height: 45px;
  border-radius: 50%;
  font-size: 24px;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  
  &:hover {
    transform: scale(1.05);
  }
`;

const Tabs = styled.div`
  display: flex;
  gap: 12px;
  margin-bottom: 20px;
`;

const Tab = styled.button`
  padding: 10px 20px;
  background: ${props => props.active ? 'white' : 'rgba(255, 255, 255, 0.2)'};
  color: ${props => props.active ? '#FF6B6B' : 'white'};
  border: none;
  border-radius: 25px;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
  
  &:hover {
    background: white;
    color: #FF6B6B;
  }
`;

const StoryGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 12px;
`;

const StoryCard = styled.div`
  background: white;
  border-radius: 16px;
  overflow: hidden;
  cursor: pointer;
  transition: transform 0.3s ease;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
  
  &:hover {
    transform: translateY(-3px);
  }
`;

const StoryImage = styled.div`
  height: 200px;
  background: ${props => props.bgColor || 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)'};
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  
  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
`;

const StoryOverlay = styled.div`
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: linear-gradient(to bottom, transparent 50%, rgba(0,0,0,0.7));
  display: flex;
  flex-direction: column;
  justify-content: flex-end;
  padding: 12px;
`;

const StoryCaption = styled.p`
  color: white;
  font-size: 14px;
  font-weight: 500;
`;

const StoryInfo = styled.div`
  padding: 12px;
  display: flex;
  align-items: center;
  gap: 10px;
`;

const UserAvatar = styled.img`
  width: 36px;
  height: 36px;
  border-radius: 50%;
  object-fit: cover;
`;

const DefaultAvatar = styled.div`
  width: 36px;
  height: 36px;
  border-radius: 50%;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 18px;
`;

const UserInfo = styled.div`
  flex: 1;
`;

const UserName = styled.p`
  font-size: 14px;
  font-weight: 600;
  color: #333;
`;

const StoryTime = styled.p`
  font-size: 12px;
  color: #999;
`;

const ViewCount = styled.div`
  display: flex;
  align-items: center;
  gap: 4px;
  font-size: 12px;
  color: #666;
`;

const MyStoryCard = styled.div`
  background: linear-gradient(135deg, #FF6B6B 0%, #FF8E53 100%);
  border-radius: 16px;
  padding: 20px;
  color: white;
  text-align: center;
  cursor: pointer;
  transition: transform 0.3s ease;
  
  &:hover {
    transform: translateY(-3px);
  }
`;

const AddStoryIcon = styled.div`
  width: 60px;
  height: 60px;
  background: rgba(255, 255, 255, 0.2);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 30px;
  margin: 0 auto 12px;
`;

const EmptyState = styled.div`
  text-align: center;
  color: white;
  padding: 60px 20px;
  
  h3 {
    font-size: 20px;
    margin-bottom: 8px;
  }
  
  p {
    font-size: 14px;
    opacity: 0.8;
    margin-bottom: 20px;
  }
`;

const UploadInput = styled.input`
  display: none;
`;

const Stories = () => {
  const [activeTab, setActiveTab] = useState('all');
  const [stories, setStories] = useState([]);
  const [myStories, setMyStories] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    fetchStories();
  }, []);

  const fetchStories = async () => {
    try {
      const [allRes, myRes] = await Promise.all([
        axios.get('/stories'),
        axios.get('/stories/my')
      ]);
      
      setStories(allRes.data.stories || []);
      setMyStories(myRes.data.stories || []);
    } catch (error) {
      console.error('Fetch stories error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const formData = new FormData();
    formData.append('media', file);

    try {
      await axios.post('/stories', formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
      fetchStories();
    } catch (error) {
      alert('Gagal upload story');
    }
  };

  const formatTime = (date) => {
    const now = new Date();
    const storyDate = new Date(date);
    const diff = now - storyDate;
    
    if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
    if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`;
    return `${Math.floor(diff / 86400000)}d ago`;
  };

  if (loading) {
    return <Container>Loading...</Container>;
  }

  return (
    <Container>
      <Header>
        <Title>Stories 📸</Title>
        <label>
          <AddButton>+</AddButton>
          <UploadInput
            type="file"
            accept="image/*,video/*"
            onChange={handleUpload}
          />
        </label>
      </Header>

      <Tabs>
        <Tab 
          active={activeTab === 'all'}
          onClick={() => setActiveTab('all')}
        >
          Semua
        </Tab>
        <Tab 
          active={activeTab === 'mine'}
          onClick={() => setActiveTab('mine')}
        >
          Story Saya ({myStories.length})
        </Tab>
      </Tabs>

      {activeTab === 'mine' ? (
        myStories.length === 0 ? (
          <EmptyState>
            <h3>Belum ada story</h3>
            <p>Bagikan momenmu sekarang!</p>
            <label>
              <MyStoryCard>
                <AddStoryIcon>+</AddStoryIcon>
                <p>Tambah Story</p>
              </MyStoryCard>
              <UploadInput
                type="file"
                accept="image/*,video/*"
                onChange={handleUpload}
              />
            </label>
          </EmptyState>
        ) : (
          <StoryGrid>
            {myStories.map((story) => (
              <StoryCard key={story._id}>
                <StoryImage bgColor={story.backgroundColor}>
                  {story.mediaUrl && <img src={story.mediaUrl} alt="Story" />}
                  <StoryOverlay>
                    <StoryCaption>{story.caption || 'My Story'}</StoryCaption>
                  </StoryOverlay>
                </StoryImage>
                <StoryInfo>
                  <ViewCount>
                    👁️ {story.views.length} views
                  </ViewCount>
                  <StoryTime>{formatTime(story.createdAt)}</StoryTime>
                </StoryInfo>
              </StoryCard>
            ))}
          </StoryGrid>
        )
      ) : (
        stories.length === 0 ? (
          <EmptyState>
            <h3>Belum ada story</h3>
            <p>Jadilah yang pertama membuat story!</p>
          </EmptyState>
        ) : (
          <StoryGrid>
            {stories.map((storyGroup) => (
              storyGroup.stories.map((story) => (
                <StoryCard key={story._id}>
                  <StoryImage bgColor={story.backgroundColor}>
                    {story.mediaUrl && <img src={story.mediaUrl} alt="Story" />}
                    <StoryOverlay>
                      <StoryCaption>{story.caption || 'Story'}</StoryCaption>
                    </StoryOverlay>
                  </StoryImage>
                  <StoryInfo>
                    {storyGroup.user?.photos?.[0]?.url ? (
                      <UserAvatar src={storyGroup.user.photos[0].url} alt={storyGroup.user.name} />
                    ) : (
                      <DefaultAvatar>👤</DefaultAvatar>
                    )}
                    <UserInfo>
                      <UserName>{storyGroup.user?.name}</UserName>
                      <StoryTime>{formatTime(story.createdAt)}</StoryTime>
                    </UserInfo>
                    <ViewCount>
                      👁️ {story.viewCount}
                    </ViewCount>
                  </StoryInfo>
                </StoryCard>
              ))
            ))}
          </StoryGrid>
        )
      )}
    </Container>
  );
};

export default Stories;
