import React from 'react';
import { useNavigate } from 'react-router-dom';
import styled from 'styled-components';
import { useAuth } from '../context/AuthContext';

const Container = styled.div`
  padding: 16px;
`;

const ProfileHeader = styled.div`
  background: white;
  border-radius: 20px;
  padding: 24px;
  text-align: center;
  margin-bottom: 16px;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
`;

const Avatar = styled.img`
  width: 120px;
  height: 120px;
  border-radius: 50%;
  object-fit: cover;
  border: 4px solid #FF6B6B;
  margin-bottom: 16px;
`;

const DefaultAvatar = styled.div`
  width: 120px;
  height: 120px;
  border-radius: 50%;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 60px;
  margin: 0 auto 16px;
`;

const Name = styled.h1`
  font-size: 24px;
  font-weight: 700;
  color: #333;
  margin-bottom: 4px;
`;

const Info = styled.p`
  font-size: 14px;
  color: #666;
  margin-bottom: 8px;
`;

const Bio = styled.p`
  font-size: 14px;
  color: #555;
  line-height: 1.5;
  margin-top: 12px;
  padding: 12px;
  background: #f5f5f5;
  border-radius: 10px;
`;

const OnlineStatus = styled.div`
  display: inline-flex;
  align-items: center;
  gap: 6px;
  background: #e8f5e9;
  color: #2e7d32;
  padding: 6px 12px;
  border-radius: 20px;
  font-size: 12px;
  font-weight: 500;
  margin-top: 8px;
`;

const OnlineDot = styled.span`
  width: 8px;
  height: 8px;
  background: #4CAF50;
  border-radius: 50%;
`;

const StatsGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 12px;
  margin-bottom: 16px;
`;

const StatCard = styled.div`
  background: white;
  border-radius: 16px;
  padding: 16px;
  text-align: center;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
`;

const StatValue = styled.div`
  font-size: 24px;
  font-weight: 700;
  color: #FF6B6B;
  margin-bottom: 4px;
`;

const StatLabel = styled.div`
  font-size: 12px;
  color: #666;
`;

const MenuSection = styled.div`
  background: white;
  border-radius: 20px;
  overflow: hidden;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
  margin-bottom: 16px;
`;

const MenuItem = styled.button`
  width: 100%;
  padding: 16px 20px;
  background: none;
  border: none;
  border-bottom: 1px solid #f0f0f0;
  display: flex;
  align-items: center;
  justify-content: space-between;
  cursor: pointer;
  transition: background 0.3s ease;
  
  &:last-child {
    border-bottom: none;
  }
  
  &:hover {
    background: #f9f9f9;
  }
`;

const MenuLeft = styled.div`
  display: flex;
  align-items: center;
  gap: 12px;
`;

const MenuIcon = styled.span`
  font-size: 20px;
`;

const MenuText = styled.span`
  font-size: 15px;
  color: #333;
  font-weight: 500;
`;

const MenuArrow = styled.span`
  font-size: 18px;
  color: #999;
`;

const PremiumBadge = styled.span`
  background: linear-gradient(135deg, #FFD700 0%, #FFA500 100%);
  color: white;
  font-size: 10px;
  font-weight: 600;
  padding: 4px 8px;
  border-radius: 10px;
  margin-left: 8px;
`;

const LogoutButton = styled.button`
  width: 100%;
  padding: 16px;
  background: #ffebee;
  color: #c62828;
  border: none;
  border-radius: 12px;
  font-size: 16px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
  
  &:hover {
    background: #ffcdd2;
  }
`;

const Profile = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  if (!user) {
    return <div>Loading...</div>;
  }

  return (
    <Container>
      <ProfileHeader>
        {user.photos?.[0]?.url ? (
          <Avatar src={user.photos[0].url} alt={user.name} />
        ) : (
          <DefaultAvatar>👤</DefaultAvatar>
        )}
        
        <Name>{user.name}</Name>
        <Info>{user.age} tahun • {user.city || 'Lokasi tidak ditentukan'}</Info>
        
        {user.isOnline && (
          <OnlineStatus>
            <OnlineDot />
            Online
          </OnlineStatus>
        )}
        
        {user.bio && <Bio>{user.bio}</Bio>}
      </ProfileHeader>

      <StatsGrid>
        <StatCard>
          <StatValue>{user.stats?.likesReceived || 0}</StatValue>
          <StatLabel>Likes</StatLabel>
        </StatCard>
        <StatCard>
          <StatValue>{user.stats?.matches || 0}</StatValue>
          <StatLabel>Matches</StatLabel>
        </StatCard>
        <StatCard>
          <StatValue>{user.stats?.profileViews || 0}</StatValue>
          <StatLabel>Profile Views</StatLabel>
        </StatCard>
      </StatsGrid>

      <MenuSection>
        <MenuItem onClick={() => navigate('/profile/edit')}>
          <MenuLeft>
            <MenuIcon>✏️</MenuIcon>
            <MenuText>Edit Profil</MenuText>
          </MenuLeft>
          <MenuArrow>›</MenuArrow>
        </MenuItem>
        
        <MenuItem onClick={() => navigate('/matches')}>
          <MenuLeft>
            <MenuIcon>💕</MenuIcon>
            <MenuText>Matches Saya</MenuText>
          </MenuLeft>
          <MenuArrow>›</MenuArrow>
        </MenuItem>
        
        <MenuItem onClick={() => navigate('/stories')}>
          <MenuLeft>
            <MenuIcon>📸</MenuIcon>
            <MenuText>Stories</MenuText>
          </MenuLeft>
          <MenuArrow>›</MenuArrow>
        </MenuItem>
        
        <MenuItem onClick={() => navigate('/nearby')}>
          <MenuLeft>
            <MenuIcon>📍</MenuIcon>
            <MenuText>Orang di Sekitar</MenuText>
          </MenuLeft>
          <MenuArrow>›</MenuArrow>
        </MenuItem>
      </MenuSection>

      <MenuSection>
        <MenuItem onClick={() => navigate('/premium')}>
          <MenuLeft>
            <MenuIcon>👑</MenuIcon>
            <MenuText>
              Premium
              {!user.isPremium && <PremiumBadge>UPGRADE</PremiumBadge>}
            </MenuText>
          </MenuLeft>
          <MenuArrow>›</MenuArrow>
        </MenuItem>
        
        <MenuItem onClick={() => navigate('/boost')}>
          <MenuLeft>
            <MenuIcon>🚀</MenuIcon>
            <MenuText>Boost Profile</MenuText>
          </MenuLeft>
          <MenuArrow>›</MenuArrow>
        </MenuItem>
        
        <MenuItem onClick={() => navigate('/settings')}>
          <MenuLeft>
            <MenuIcon>⚙️</MenuIcon>
            <MenuText>Pengaturan</MenuText>
          </MenuLeft>
          <MenuArrow>›</MenuArrow>
        </MenuItem>
        
        <MenuItem onClick={() => navigate('/help')}>
          <MenuLeft>
            <MenuIcon>❓</MenuIcon>
            <MenuText>Bantuan</MenuText>
          </MenuLeft>
          <MenuArrow>›</MenuArrow>
        </MenuItem>
      </MenuSection>

      <LogoutButton onClick={handleLogout}>
        🚪 Keluar
      </LogoutButton>
    </Container>
  );
};

export default Profile;
