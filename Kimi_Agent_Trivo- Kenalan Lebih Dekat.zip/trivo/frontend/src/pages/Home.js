import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import styled from 'styled-components';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';

const Container = styled.div`
  padding: 16px;
`;

const Section = styled.div`
  margin-bottom: 24px;
`;

const SectionHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
`;

const SectionTitle = styled.h2`
  font-size: 18px;
  font-weight: 600;
  color: white;
`;

const SeeAllLink = styled.button`
  background: none;
  border: none;
  color: rgba(255, 255, 255, 0.8);
  font-size: 14px;
  cursor: pointer;
  
  &:hover {
    color: white;
  }
`;

const StoriesContainer = styled.div`
  display: flex;
  gap: 12px;
  overflow-x: auto;
  padding-bottom: 8px;
  
  &::-webkit-scrollbar {
    display: none;
  }
`;

const StoryItem = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  cursor: pointer;
  flex-shrink: 0;
`;

const StoryRing = styled.div`
  width: 70px;
  height: 70px;
  border-radius: 50%;
  padding: 3px;
  background: ${props => props.hasStory 
    ? 'linear-gradient(135deg, #FF6B6B 0%, #FF8E53 50%, #FFD93D 100%)' 
    : '#e0e0e0'};
  margin-bottom: 6px;
`;

const StoryAvatar = styled.img`
  width: 100%;
  height: 100%;
  border-radius: 50%;
  object-fit: cover;
  border: 3px solid white;
`;

const StoryName = styled.span`
  font-size: 12px;
  color: white;
  max-width: 70px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
`;

const AddStoryButton = styled.div`
  width: 70px;
  height: 70px;
  border-radius: 50%;
  background: white;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 30px;
  color: #FF6B6B;
  border: 3px dashed #FF6B6B;
  cursor: pointer;
  flex-shrink: 0;
  margin-bottom: 6px;
`;

const CardGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 12px;
`;

const UserCard = styled.div`
  background: white;
  border-radius: 16px;
  overflow: hidden;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
  cursor: pointer;
  transition: transform 0.3s ease;
  
  &:hover {
    transform: translateY(-3px);
  }
`;

const CardImage = styled.div`
  height: 150px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  position: relative;
  
  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
`;

const OnlineIndicator = styled.div`
  position: absolute;
  top: 8px;
  right: 8px;
  width: 12px;
  height: 12px;
  background: #4CAF50;
  border-radius: 50%;
  border: 2px solid white;
`;

const DistanceBadge = styled.div`
  position: absolute;
  bottom: 8px;
  left: 8px;
  background: rgba(0, 0, 0, 0.6);
  color: white;
  padding: 4px 8px;
  border-radius: 12px;
  font-size: 11px;
  display: flex;
  align-items: center;
  gap: 4px;
`;

const CardInfo = styled.div`
  padding: 12px;
`;

const CardName = styled.h3`
  font-size: 15px;
  font-weight: 600;
  color: #333;
  margin-bottom: 4px;
`;

const CardDetails = styled.p`
  font-size: 12px;
  color: #666;
`;

const ActionButtons = styled.div`
  display: flex;
  gap: 8px;
  margin-top: 8px;
`;

const ActionButton = styled.button`
  flex: 1;
  padding: 8px;
  border: none;
  border-radius: 8px;
  font-size: 18px;
  cursor: pointer;
  transition: all 0.3s ease;
  
  &.like {
    background: #FF6B6B;
    color: white;
    
    &:hover {
      background: #ff5252;
    }
  }
  
  &.skip {
    background: #e0e0e0;
    color: #666;
    
    &:hover {
      background: #d0d0d0;
    }
  }
`;

const LoadingText = styled.div`
  text-align: center;
  color: white;
  padding: 40px;
`;

const EmptyState = styled.div`
  text-align: center;
  color: white;
  padding: 40px;
  
  h3 {
    font-size: 18px;
    margin-bottom: 8px;
  }
  
  p {
    font-size: 14px;
    opacity: 0.8;
  }
`;

const Home = () => {
  const [users, setUsers] = useState([]);
  const [stories, setStories] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const { user, updateLocation } = useAuth();

  // Get user's location
  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          await updateLocation(
            position.coords.latitude,
            position.coords.longitude
          );
        },
        (error) => {
          console.error('Location error:', error);
        }
      );
    }
  }, []);

  // Fetch users and stories
  useEffect(() => {
    const fetchData = async () => {
      try {
        const [usersRes, storiesRes] = await Promise.all([
          axios.get('/users/explore'),
          axios.get('/stories')
        ]);
        
        setUsers(usersRes.data.users || []);
        setStories(storiesRes.data.stories || []);
      } catch (error) {
        console.error('Fetch data error:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const handleSwipe = async (targetUserId, action) => {
    try {
      await axios.post('/matches/swipe', {
        targetUserId,
        action
      });
      
      // Remove user from list
      setUsers(users.filter(u => u._id !== targetUserId));
    } catch (error) {
      console.error('Swipe error:', error);
    }
  };

  if (loading) {
    return <LoadingText>Loading...</LoadingText>;
  }

  return (
    <Container>
      {/* Stories Section */}
      <Section>
        <StoriesContainer>
          <StoryItem>
            <AddStoryButton onClick={() => navigate('/stories')}>
              +
            </AddStoryButton>
            <StoryName>Your Story</StoryName>
          </StoryItem>
          
          {stories.map((storyGroup) => (
            <StoryItem 
              key={storyGroup.user._id}
              onClick={() => navigate('/stories')}
            >
              <StoryRing hasStory={true}>
                <StoryAvatar 
                  src={storyGroup.user.photos?.[0]?.url || '/default-avatar.png'} 
                  alt={storyGroup.user.name}
                />
              </StoryRing>
              <StoryName>{storyGroup.user.name}</StoryName>
            </StoryItem>
          ))}
        </StoriesContainer>
      </Section>

      {/* Nearby Users Section */}
      <Section>
        <SectionHeader>
          <SectionTitle>Orang di Sekitar 💫</SectionTitle>
          <SeeAllLink onClick={() => navigate('/nearby')}>
            Lihat Semua
          </SeeAllLink>
        </SectionHeader>

        {users.length === 0 ? (
          <EmptyState>
            <h3>Tidak ada user di sekitar</h3>
            <p>Coba perluas radius pencarian atau coba lagi nanti</p>
          </EmptyState>
        ) : (
          <CardGrid>
            {users.slice(0, 6).map((user) => (
              <UserCard key={user._id}>
                <CardImage onClick={() => navigate(`/user/${user._id}`)}>
                  {user.photos?.[0]?.url ? (
                    <img src={user.photos[0].url} alt={user.name} />
                  ) : (
                    <div style={{ 
                      display: 'flex', 
                      alignItems: 'center', 
                      justifyContent: 'center',
                      height: '100%',
                      fontSize: '50px'
                    }}>
                      👤
                    </div>
                  )}
                  {user.isOnline && <OnlineIndicator />}
                  {user.distance && (
                    <DistanceBadge>
                      📍 {user.distance} km
                    </DistanceBadge>
                  )}
                </CardImage>
                
                <CardInfo>
                  <CardName>{user.name}, {user.age}</CardName>
                  <CardDetails>{user.city || 'Unknown location'}</CardDetails>
                  
                  <ActionButtons>
                    <ActionButton 
                      className="skip"
                      onClick={() => handleSwipe(user._id, 'skip')}
                    >
                      ❌
                    </ActionButton>
                    <ActionButton 
                      className="like"
                      onClick={() => handleSwipe(user._id, 'like')}
                    >
                      ❤️
                    </ActionButton>
                  </ActionButtons>
                </CardInfo>
              </UserCard>
            ))}
          </CardGrid>
        )}
      </Section>
    </Container>
  );
};

export default Home;
