import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import styled from 'styled-components';
import axios from 'axios';

const Container = styled.div`
  padding: 16px;
`;

const Header = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
`;

const Title = styled.h1`
  font-size: 24px;
  font-weight: 700;
  color: white;
`;

const GoLiveButton = styled.button`
  background: linear-gradient(135deg, #FF6B6B 0%, #FF8E53 100%);
  color: white;
  border: none;
  padding: 10px 20px;
  border-radius: 25px;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 6px;
  transition: all 0.3s ease;
  
  &:hover {
    transform: scale(1.05);
    box-shadow: 0 5px 20px rgba(255, 107, 107, 0.4);
  }
`;

const LiveIndicator = styled.div`
  display: flex;
  align-items: center;
  gap: 6px;
  background: rgba(255, 0, 0, 0.2);
  color: white;
  padding: 6px 12px;
  border-radius: 20px;
  font-size: 12px;
  font-weight: 500;
`;

const LiveDot = styled.span`
  width: 8px;
  height: 8px;
  background: #ff0000;
  border-radius: 50%;
  animation: pulse 1.5s infinite;
  
  @keyframes pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.5; }
  }
`;

const FeaturedStream = styled.div`
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border-radius: 20px;
  overflow: hidden;
  margin-bottom: 20px;
  cursor: pointer;
  position: relative;
`;

const FeaturedImage = styled.div`
  height: 200px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 80px;
`;

const FeaturedInfo = styled.div`
  padding: 16px;
  color: white;
`;

const FeaturedTitle = styled.h3`
  font-size: 18px;
  font-weight: 600;
  margin-bottom: 8px;
`;

const FeaturedStreamer = styled.div`
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 14px;
`;

const ViewerCount = styled.div`
  position: absolute;
  top: 12px;
  right: 12px;
  background: rgba(0, 0, 0, 0.6);
  color: white;
  padding: 6px 12px;
  border-radius: 15px;
  font-size: 12px;
  display: flex;
  align-items: center;
  gap: 4px;
`;

const SectionTitle = styled.h2`
  font-size: 18px;
  font-weight: 600;
  color: white;
  margin-bottom: 12px;
`;

const StreamGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 12px;
`;

const StreamCard = styled.div`
  background: white;
  border-radius: 16px;
  overflow: hidden;
  cursor: pointer;
  transition: transform 0.3s ease;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
  
  &:hover {
    transform: translateY(-3px);
  }
`;

const StreamThumbnail = styled.div`
  height: 120px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 50px;
`;

const LiveBadge = styled.div`
  position: absolute;
  top: 8px;
  left: 8px;
  background: #ff0000;
  color: white;
  padding: 4px 8px;
  border-radius: 4px;
  font-size: 10px;
  font-weight: 600;
`;

const StreamInfo = styled.div`
  padding: 12px;
`;

const StreamTitle = styled.h4`
  font-size: 14px;
  font-weight: 600;
  color: #333;
  margin-bottom: 4px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
`;

const StreamerName = styled.p`
  font-size: 12px;
  color: #666;
`;

const StreamStats = styled.div`
  display: flex;
  align-items: center;
  gap: 8px;
  margin-top: 8px;
  font-size: 11px;
  color: #999;
`;

const EmptyState = styled.div`
  text-align: center;
  color: white;
  padding: 60px 20px;
  
  h3 {
    font-size: 20px;
    margin-bottom: 8px;
  }
  
  p {
    font-size: 14px;
    opacity: 0.8;
    margin-bottom: 20px;
  }
`;

const Live = () => {
  const [streams, setStreams] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    fetchStreams();
  }, []);

  const fetchStreams = async () => {
    try {
      const response = await axios.get('/live');
      setStreams(response.data.streams || []);
    } catch (error) {
      console.error('Fetch streams error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleGoLive = async () => {
    const title = prompt('Masukkan judul live stream:');
    if (title) {
      try {
        const response = await axios.post('/live/start', { title });
        const streamId = response.data.stream._id;
        navigate(`/live/${streamId}`);
      } catch (error) {
        alert('Gagal memulai live stream');
      }
    }
  };

  if (loading) {
    return <Container>Loading...</Container>;
  }

  return (
    <Container>
      <Header>
        <div>
          <Title>Live 🔴</Title>
          <LiveIndicator>
            <LiveDot />
            {streams.length} LIVE
          </LiveIndicator>
        </div>
        <GoLiveButton onClick={handleGoLive}>
          🔴 Go Live
        </GoLiveButton>
      </Header>

      {streams.length === 0 ? (
        <EmptyState>
          <h3>Tidak ada live stream</h3>
          <p>Jadilah yang pertama live!</p>
          <GoLiveButton onClick={handleGoLive}>
            🔴 Mulai Live
          </GoLiveButton>
        </EmptyState>
      ) : (
        <>
          {/* Featured Stream */}
          {streams[0] && (
            <FeaturedStream onClick={() => navigate(`/live/${streams[0]._id}`)}>
              <FeaturedImage>
                📹
              </FeaturedImage>
              <ViewerCount>
                👥 {streams[0].viewerCount}
              </ViewerCount>
              <FeaturedInfo>
                <FeaturedTitle>{streams[0].title}</FeaturedTitle>
                <FeaturedStreamer>
                  <span>👤</span>
                  {streams[0].streamer?.name}
                </FeaturedStreamer>
              </FeaturedInfo>
            </FeaturedStream>
          )}

          {/* Other Streams */}
          <SectionTitle>Live Lainnya</SectionTitle>
          <StreamGrid>
            {streams.slice(1).map((stream) => (
              <StreamCard 
                key={stream._id}
                onClick={() => navigate(`/live/${stream._id}`)}
              >
                <StreamThumbnail>
                  <LiveBadge>LIVE</LiveBadge>
                  📹
                </StreamThumbnail>
                <StreamInfo>
                  <StreamTitle>{stream.title}</StreamTitle>
                  <StreamerName>{stream.streamer?.name}</StreamerName>
                  <StreamStats>
                    <span>👥 {stream.viewerCount}</span>
                    <span>💎 {stream.totalGifts}</span>
                  </StreamStats>
                </StreamInfo>
              </StreamCard>
            ))}
          </StreamGrid>
        </>
      )}
    </Container>
  );
};

export default Live;
