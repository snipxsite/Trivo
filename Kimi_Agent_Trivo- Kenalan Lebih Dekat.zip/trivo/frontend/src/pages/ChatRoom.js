import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import styled from 'styled-components';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';
import { useSocket } from '../context/SocketContext';

const Container = styled.div`
  display: flex;
  flex-direction: column;
  height: 100vh;
  background: #f5f5f5;
`;

const Header = styled.div`
  background: white;
  padding: 12px 16px;
  display: flex;
  align-items: center;
  gap: 12px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  z-index: 10;
`;

const BackButton = styled.button`
  background: none;
  border: none;
  font-size: 24px;
  cursor: pointer;
  padding: 5px;
`;

const UserInfo = styled.div`
  flex: 1;
  display: flex;
  align-items: center;
  gap: 10px;
  cursor: pointer;
`;

const Avatar = styled.img`
  width: 40px;
  height: 40px;
  border-radius: 50%;
  object-fit: cover;
`;

const DefaultAvatar = styled.div`
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 20px;
`;

const UserDetails = styled.div`
  flex: 1;
`;

const UserName = styled.h3`
  font-size: 16px;
  font-weight: 600;
  color: #333;
`;

const UserStatus = styled.p`
  font-size: 12px;
  color: ${props => props.online ? '#4CAF50' : '#999'};
`;

const MoreButton = styled.button`
  background: none;
  border: none;
  font-size: 20px;
  cursor: pointer;
  padding: 5px;
`;

const MessagesContainer = styled.div`
  flex: 1;
  overflow-y: auto;
  padding: 16px;
  display: flex;
  flex-direction: column;
  gap: 12px;
`;

const MessageGroup = styled.div`
  display: flex;
  flex-direction: column;
  align-items: ${props => props.sent ? 'flex-end' : 'flex-start'};
  gap: 4px;
`;

const MessageBubble = styled.div`
  max-width: 70%;
  padding: 12px 16px;
  border-radius: 18px;
  background: ${props => props.sent 
    ? 'linear-gradient(135deg, #FF6B6B 0%, #FF8E53 100%)' 
    : 'white'};
  color: ${props => props.sent ? 'white' : '#333'};
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
  word-wrap: break-word;
`;

const MessageTime = styled.span`
  font-size: 11px;
  color: #999;
  margin-top: 2px;
`;

const ReadStatus = styled.span`
  font-size: 11px;
  color: ${props => props.read ? '#4CAF50' : '#999'};
  margin-left: 4px;
`;

const InputContainer = styled.div`
  background: white;
  padding: 12px 16px;
  display: flex;
  align-items: center;
  gap: 10px;
  box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.1);
`;

const AttachButton = styled.button`
  background: none;
  border: none;
  font-size: 24px;
  cursor: pointer;
  padding: 5px;
`;

const Input = styled.input`
  flex: 1;
  padding: 12px 16px;
  border: 1px solid #e0e0e0;
  border-radius: 25px;
  outline: none;
  font-size: 15px;
  
  &:focus {
    border-color: #FF6B6B;
  }
`;

const SendButton = styled.button`
  background: linear-gradient(135deg, #FF6B6B 0%, #FF8E53 100%);
  color: white;
  border: none;
  width: 45px;
  height: 45px;
  border-radius: 50%;
  font-size: 20px;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.3s ease;
  
  &:hover {
    transform: scale(1.05);
  }
  
  &:disabled {
    opacity: 0.5;
    cursor: not-allowed;
    transform: none;
  }
`;

const TypingIndicator = styled.div`
  font-size: 12px;
  color: #999;
  font-style: italic;
  padding: 8px 16px;
`;

const ChatRoom = () => {
  const { roomId } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { joinRoom, leaveRoom, sendTyping, onEvent, offEvent } = useSocket();
  
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [otherUser, setOtherUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef(null);

  useEffect(() => {
    fetchMessages();
    joinRoom(roomId);

    return () => {
      leaveRoom(roomId);
    };
  }, [roomId]);

  useEffect(() => {
    const handleNewMessage = (data) => {
      if (data.roomId === roomId) {
        setMessages(prev => [...prev, data.message]);
        scrollToBottom();
      }
    };

    const handleTyping = (data) => {
      if (data.roomId === roomId && data.userId !== user.id) {
        setIsTyping(data.isTyping);
      }
    };

    onEvent('new_message', handleNewMessage);
    onEvent('typing', handleTyping);

    return () => {
      offEvent('new_message', handleNewMessage);
      offEvent('typing', handleTyping);
    };
  }, [roomId, onEvent, offEvent, user.id]);

  const fetchMessages = async () => {
    try {
      const response = await axios.get(`/chats/${roomId}/messages`);
      setMessages(response.data.messages || []);
      
      // Get other user info from first message
      if (response.data.messages.length > 0) {
        const firstMsg = response.data.messages[0];
        const other = firstMsg.sender._id === user.id 
          ? firstMsg.receiver 
          : firstMsg.sender;
        setOtherUser(other);
      }
      
      scrollToBottom();
    } catch (error) {
      console.error('Fetch messages error:', error);
    } finally {
      setLoading(false);
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSend = async () => {
    if (!newMessage.trim()) return;

    try {
      await axios.post(`/chats/${roomId}/messages`, {
        content: newMessage,
        messageType: 'text'
      });
      
      setNewMessage('');
      sendTyping(roomId, false);
    } catch (error) {
      console.error('Send message error:', error);
    }
  };

  const handleTyping = (e) => {
    setNewMessage(e.target.value);
    sendTyping(roomId, e.target.value.length > 0);
  };

  const formatTime = (date) => {
    return new Date(date).toLocaleTimeString('id-ID', {
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (loading) {
    return <Container>Loading...</Container>;
  }

  return (
    <Container>
      <Header>
        <BackButton onClick={() => navigate('/chat')}>
          ←
        </BackButton>
        
        <UserInfo onClick={() => otherUser && navigate(`/user/${otherUser._id}`)}>
          {otherUser?.photos?.[0]?.url ? (
            <Avatar src={otherUser.photos[0].url} alt={otherUser.name} />
          ) : (
            <DefaultAvatar>👤</DefaultAvatar>
          )}
          
          <UserDetails>
            <UserName>{otherUser?.name || 'Unknown'}</UserName>
            <UserStatus online={otherUser?.isOnline}>
              {otherUser?.isOnline ? 'Online' : 'Offline'}
            </UserStatus>
          </UserDetails>
        </UserInfo>
        
        <MoreButton>⋮</MoreButton>
      </Header>

      <MessagesContainer>
        {messages.map((message, index) => {
          const isSent = message.sender._id === user.id;
          
          return (
            <MessageGroup key={message._id} sent={isSent}>
              <MessageBubble sent={isSent}>
                {message.content}
              </MessageBubble>
              <MessageTime>
                {formatTime(message.createdAt)}
                {isSent && (
                  <ReadStatus read={message.status === 'read'}>
                    {message.status === 'read' ? '✓✓' : '✓'}
                  </ReadStatus>
                )}
              </MessageTime>
            </MessageGroup>
          );
        })}
        
        {isTyping && (
          <TypingIndicator>Typing...</TypingIndicator>
        )}
        
        <div ref={messagesEndRef} />
      </MessagesContainer>

      <InputContainer>
        <AttachButton>📎</AttachButton>
        
        <Input
          type="text"
          placeholder="Ketik pesan..."
          value={newMessage}
          onChange={handleTyping}
          onKeyPress={(e) => e.key === 'Enter' && handleSend()}
        />
        
        <SendButton 
          onClick={handleSend}
          disabled={!newMessage.trim()}
        >
          ➤
        </SendButton>
      </InputContainer>
    </Container>
  );
};

export default ChatRoom;
