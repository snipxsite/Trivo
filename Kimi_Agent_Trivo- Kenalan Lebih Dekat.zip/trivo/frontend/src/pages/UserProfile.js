import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import styled from 'styled-components';
import axios from 'axios';

const Container = styled.div`
  padding: 16px;
`;

const ProfileCard = styled.div`
  background: white;
  border-radius: 20px;
  overflow: hidden;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
`;

const CoverImage = styled.div`
  height: 200px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  position: relative;
  
  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
`;

const BackButton = styled.button`
  position: absolute;
  top: 16px;
  left: 16px;
  background: rgba(255, 255, 255, 0.9);
  border: none;
  width: 40px;
  height: 40px;
  border-radius: 50%;
  font-size: 20px;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 10;
`;

const MoreButton = styled.button`
  position: absolute;
  top: 16px;
  right: 16px;
  background: rgba(255, 255, 255, 0.9);
  border: none;
  width: 40px;
  height: 40px;
  border-radius: 50%;
  font-size: 20px;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 10;
`;

const ProfileInfo = styled.div`
  padding: 0 20px 20px;
  position: relative;
`;

const Avatar = styled.img`
  width: 120px;
  height: 120px;
  border-radius: 50%;
  object-fit: cover;
  border: 5px solid white;
  margin-top: -60px;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
`;

const DefaultAvatar = styled.div`
  width: 120px;
  height: 120px;
  border-radius: 50%;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 60px;
  border: 5px solid white;
  margin-top: -60px;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
`;

const NameSection = styled.div`
  margin-top: 16px;
`;

const Name = styled.h1`
  font-size: 24px;
  font-weight: 700;
  color: #333;
  display: flex;
  align-items: center;
  gap: 8px;
`;

const VerifiedBadge = styled.span`
  background: #2196F3;
  color: white;
  width: 20px;
  height: 20px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 12px;
`;

const Info = styled.p`
  font-size: 14px;
  color: #666;
  margin-top: 4px;
`;

const OnlineStatus = styled.div`
  display: inline-flex;
  align-items: center;
  gap: 6px;
  background: #e8f5e9;
  color: #2e7d32;
  padding: 6px 12px;
  border-radius: 20px;
  font-size: 12px;
  font-weight: 500;
  margin-top: 8px;
`;

const OnlineDot = styled.span`
  width: 8px;
  height: 8px;
  background: #4CAF50;
  border-radius: 50%;
`;

const Bio = styled.p`
  font-size: 14px;
  color: #555;
  line-height: 1.6;
  margin-top: 16px;
  padding: 16px;
  background: #f9f9f9;
  border-radius: 12px;
`;

const ActionButtons = styled.div`
  display: flex;
  gap: 12px;
  margin-top: 20px;
`;

const ActionButton = styled.button`
  flex: 1;
  padding: 14px;
  border: none;
  border-radius: 12px;
  font-size: 16px;
  font-weight: 600;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  transition: all 0.3s ease;
  
  &.like {
    background: linear-gradient(135deg, #FF6B6B 0%, #FF8E53 100%);
    color: white;
    
    &:hover {
      transform: translateY(-2px);
      box-shadow: 0 8px 20px rgba(255, 107, 107, 0.4);
    }
  }
  
  &.superlike {
    background: linear-gradient(135deg, #FFD700 0%, #FFA500 100%);
    color: white;
    
    &:hover {
      transform: translateY(-2px);
      box-shadow: 0 8px 20px rgba(255, 215, 0, 0.4);
    }
  }
  
  &.chat {
    background: #e3f2fd;
    color: #1976d2;
    
    &:hover {
      background: #bbdefb;
    }
  }
`;

const DetailsSection = styled.div`
  margin-top: 20px;
  padding-top: 20px;
  border-top: 1px solid #eee;
`;

const DetailItem = styled.div`
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px 0;
  
  &:not(:last-child) {
    border-bottom: 1px solid #f0f0f0;
  }
`;

const DetailIcon = styled.span`
  font-size: 20px;
  width: 30px;
`;

const DetailText = styled.div`
  flex: 1;
`;

const DetailLabel = styled.p`
  font-size: 12px;
  color: #999;
`;

const DetailValue = styled.p`
  font-size: 14px;
  color: #333;
  font-weight: 500;
`;

const InterestsSection = styled.div`
  margin-top: 20px;
`;

const InterestsTitle = styled.h3`
  font-size: 16px;
  font-weight: 600;
  color: #333;
  margin-bottom: 12px;
`;

const InterestsList = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
`;

const InterestTag = styled.span`
  background: #f0f0f0;
  color: #666;
  padding: 8px 16px;
  border-radius: 20px;
  font-size: 13px;
`;

const LoadingText = styled.div`
  text-align: center;
  color: white;
  padding: 40px;
`;

const UserProfile = () => {
  const { userId } = useParams();
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchUserProfile();
  }, [userId]);

  const fetchUserProfile = async () => {
    try {
      const response = await axios.get(`/users/${userId}`);
      setUser(response.data.user);
    } catch (error) {
      console.error('Fetch user profile error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleLike = async () => {
    try {
      await axios.post('/matches/swipe', {
        targetUserId: userId,
        action: 'like'
      });
      alert('Like terkirim!');
    } catch (error) {
      alert(error.response?.data?.message || 'Gagal mengirim like');
    }
  };

  const handleSuperLike = async () => {
    try {
      await axios.post(`/matches/${userId}/superlike`);
      alert('Super Like terkirim!');
    } catch (error) {
      alert(error.response?.data?.message || 'Gagal mengirim super like');
    }
  };

  if (loading) {
    return <LoadingText>Loading...</LoadingText>;
  }

  if (!user) {
    return <LoadingText>User not found</LoadingText>;
  }

  return (
    <Container>
      <ProfileCard>
        <CoverImage>
          {user.photos?.[1]?.url ? (
            <img src={user.photos[1].url} alt="Cover" />
          ) : (
            <div style={{ height: '100%' }} />
          )}
          <BackButton onClick={() => navigate(-1)}>←</BackButton>
          <MoreButton>⋮</MoreButton>
        </CoverImage>

        <ProfileInfo>
          {user.photos?.[0]?.url ? (
            <Avatar src={user.photos[0].url} alt={user.name} />
          ) : (
            <DefaultAvatar>👤</DefaultAvatar>
          )}

          <NameSection>
            <Name>
              {user.name}, {user.age}
              {user.isVerified && <VerifiedBadge>✓</VerifiedBadge>}
            </Name>
            <Info>{user.city || 'Lokasi tidak ditentukan'}</Info>
            
            {user.isOnline && (
              <OnlineStatus>
                <OnlineDot />
                Online
              </OnlineStatus>
            )}
          </NameSection>

          {user.bio && <Bio>{user.bio}</Bio>}

          <ActionButtons>
            <ActionButton className="like" onClick={handleLike}>
              ❤️ Like
            </ActionButton>
            <ActionButton className="superlike" onClick={handleSuperLike}>
              ⭐ Super
            </ActionButton>
          </ActionButtons>

          <DetailsSection>
            <DetailItem>
              <DetailIcon>📍</DetailIcon>
              <DetailText>
                <DetailLabel>Lokasi</DetailLabel>
                <DetailValue>{user.city || 'Tidak ditentukan'}</DetailValue>
              </DetailText>
            </DetailItem>

            <DetailItem>
              <DetailIcon>🎂</DetailIcon>
              <DetailText>
                <DetailLabel>Umur</DetailLabel>
                <DetailValue>{user.age} tahun</DetailValue>
              </DetailText>
            </DetailItem>

            <DetailItem>
              <DetailIcon>⚧</DetailIcon>
              <DetailText>
                <DetailLabel>Gender</DetailLabel>
                <DetailValue>
                  {user.gender === 'male' ? 'Laki-laki' :
                   user.gender === 'female' ? 'Perempuan' :
                   user.gender === 'other' ? 'Lainnya' : 'Rahasia'}
                </DetailValue>
              </DetailText>
            </DetailItem>

            <DetailItem>
              <DetailIcon>👁️</DetailIcon>
              <DetailText>
                <DetailLabel>Profile Views</DetailLabel>
                <DetailValue>{user.stats?.profileViews || 0} views</DetailValue>
              </DetailText>
            </DetailItem>
          </DetailsSection>

          {user.interests && user.interests.length > 0 && (
            <InterestsSection>
              <InterestsTitle>Interests</InterestsTitle>
              <InterestsList>
                {user.interests.map((interest, idx) => (
                  <InterestTag key={idx}>{interest}</InterestTag>
                ))}
              </InterestsList>
            </InterestsSection>
          )}
        </ProfileInfo>
      </ProfileCard>
    </Container>
  );
};

export default UserProfile;
