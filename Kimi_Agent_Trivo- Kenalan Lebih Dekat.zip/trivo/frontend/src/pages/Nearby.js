import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import styled from 'styled-components';
import axios from 'axios';

const Container = styled.div`
  padding: 16px;
`;

const Header = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
`;

const Title = styled.h1`
  font-size: 24px;
  font-weight: 700;
  color: white;
`;

const RadiusSelector = styled.select`
  padding: 8px 16px;
  border: none;
  border-radius: 20px;
  background: white;
  color: #333;
  font-size: 14px;
  cursor: pointer;
`;

const MapPlaceholder = styled.div`
  height: 200px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border-radius: 20px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  color: white;
  margin-bottom: 20px;
  position: relative;
  overflow: hidden;
`;

const MapIcon = styled.div`
  font-size: 50px;
  margin-bottom: 10px;
`;

const MapText = styled.p`
  font-size: 14px;
  opacity: 0.9;
`;

const UserDots = styled.div`
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
`;

const UserDot = styled.div`
  position: absolute;
  width: 12px;
  height: 12px;
  background: #FF6B6B;
  border-radius: 50%;
  border: 2px solid white;
  top: ${props => props.top}%;
  left: ${props => props.left}%;
`;

const UserList = styled.div`
  display: flex;
  flex-direction: column;
  gap: 12px;
`;

const UserCard = styled.div`
  background: white;
  border-radius: 16px;
  padding: 16px;
  display: flex;
  align-items: center;
  gap: 12px;
  cursor: pointer;
  transition: all 0.3s ease;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  
  &:hover {
    transform: translateX(5px);
  }
`;

const Avatar = styled.img`
  width: 70px;
  height: 70px;
  border-radius: 50%;
  object-fit: cover;
`;

const DefaultAvatar = styled.div`
  width: 70px;
  height: 70px;
  border-radius: 50%;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 35px;
`;

const AvatarContainer = styled.div`
  position: relative;
`;

const OnlineIndicator = styled.div`
  position: absolute;
  bottom: 3px;
  right: 3px;
  width: 16px;
  height: 16px;
  background: #4CAF50;
  border-radius: 50%;
  border: 3px solid white;
`;

const UserInfo = styled.div`
  flex: 1;
`;

const UserName = styled.h3`
  font-size: 16px;
  font-weight: 600;
  color: #333;
  margin-bottom: 4px;
`;

const UserDetails = styled.p`
  font-size: 13px;
  color: #666;
  margin-bottom: 4px;
`;

const DistanceBadge = styled.span`
  display: inline-flex;
  align-items: center;
  gap: 4px;
  background: #e3f2fd;
  color: #1976d2;
  padding: 4px 10px;
  border-radius: 12px;
  font-size: 12px;
  font-weight: 500;
`;

const ActionButtons = styled.div`
  display: flex;
  flex-direction: column;
  gap: 8px;
`;

const ActionButton = styled.button`
  width: 44px;
  height: 44px;
  border-radius: 50%;
  border: none;
  font-size: 20px;
  cursor: pointer;
  transition: all 0.3s ease;
  
  &.like {
    background: #FF6B6B;
    color: white;
    
    &:hover {
      transform: scale(1.1);
    }
  }
  
  &.skip {
    background: #e0e0e0;
    color: #666;
    
    &:hover {
      background: #d0d0d0;
    }
  }
`;

const EmptyState = styled.div`
  text-align: center;
  color: white;
  padding: 60px 20px;
  
  h3 {
    font-size: 20px;
    margin-bottom: 8px;
  }
  
  p {
    font-size: 14px;
    opacity: 0.8;
  }
`;

const Nearby = () => {
  const [users, setUsers] = useState([]);
  const [radius, setRadius] = useState(10);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    fetchNearbyUsers();
  }, [radius]);

  const fetchNearbyUsers = async () => {
    try {
      const response = await axios.get(`/users/nearby?radius=${radius}`);
      setUsers(response.data.users || []);
    } catch (error) {
      console.error('Fetch nearby users error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSwipe = async (userId, action) => {
    try {
      await axios.post('/matches/swipe', {
        targetUserId: userId,
        action
      });
      
      setUsers(users.filter(u => u._id !== userId));
    } catch (error) {
      console.error('Swipe error:', error);
    }
  };

  if (loading) {
    return <Container>Loading...</Container>;
  }

  return (
    <Container>
      <Header>
        <Title>Di Sekitar 📍</Title>
        <RadiusSelector 
          value={radius}
          onChange={(e) => setRadius(Number(e.target.value))}
        >
          <option value={1}>1 km</option>
          <option value={5}>5 km</option>
          <option value={10}>10 km</option>
          <option value={20}>20 km</option>
          <option value={50}>50 km</option>
        </RadiusSelector>
      </Header>

      <MapPlaceholder>
        <UserDots>
          {users.slice(0, 10).map((user, index) => (
            <UserDot 
              key={user._id}
              top={20 + Math.random() * 60}
              left={10 + Math.random() * 80}
            />
          ))}
        </UserDots>
        <MapIcon>🗺️</MapIcon>
        <MapText>{users.length} orang di radius {radius} km</MapText>
      </MapPlaceholder>

      {users.length === 0 ? (
        <EmptyState>
          <h3>Tidak ada user di sekitar</h3>
          <p>Coba perluas radius pencarian</p>
        </EmptyState>
      ) : (
        <UserList>
          {users.map((user) => (
            <UserCard key={user._id}>
              <AvatarContainer onClick={() => navigate(`/user/${user._id}`)}>
                {user.photos?.[0]?.url ? (
                  <Avatar src={user.photos[0].url} alt={user.name} />
                ) : (
                  <DefaultAvatar>👤</DefaultAvatar>
                )}
                {user.isOnline && <OnlineIndicator />}
              </AvatarContainer>

              <UserInfo onClick={() => navigate(`/user/${user._id}`)}>
                <UserName>{user.name}, {user.age}</UserName>
                <UserDetails>{user.city || 'Lokasi tidak diketahui'}</UserDetails>
                <DistanceBadge>
                  📍 {user.distance} km dari kamu
                </DistanceBadge>
              </UserInfo>

              <ActionButtons>
                <ActionButton 
                  className="skip"
                  onClick={() => handleSwipe(user._id, 'skip')}
                >
                  ❌
                </ActionButton>
                <ActionButton 
                  className="like"
                  onClick={() => handleSwipe(user._id, 'like')}
                >
                  ❤️
                </ActionButton>
              </ActionButtons>
            </UserCard>
          ))}
        </UserList>
      )}
    </Container>
  );
};

export default Nearby;
