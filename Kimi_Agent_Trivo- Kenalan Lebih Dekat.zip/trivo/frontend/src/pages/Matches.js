import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import styled from 'styled-components';
import axios from 'axios';

const Container = styled.div`
  padding: 16px;
`;

const Title = styled.h1`
  font-size: 24px;
  font-weight: 700;
  color: white;
  margin-bottom: 20px;
`;

const Tabs = styled.div`
  display: flex;
  gap: 12px;
  margin-bottom: 20px;
`;

const Tab = styled.button`
  padding: 10px 20px;
  background: ${props => props.active ? 'white' : 'rgba(255, 255, 255, 0.2)'};
  color: ${props => props.active ? '#FF6B6B' : 'white'};
  border: none;
  border-radius: 25px;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
  
  &:hover {
    background: white;
    color: #FF6B6B;
  }
`;

const MatchGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 12px;
`;

const MatchCard = styled.div`
  background: white;
  border-radius: 16px;
  overflow: hidden;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
  cursor: pointer;
  transition: transform 0.3s ease;
  
  &:hover {
    transform: translateY(-3px);
  }
`;

const MatchImage = styled.div`
  height: 160px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  position: relative;
  
  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
`;

const NewMatchBadge = styled.div`
  position: absolute;
  top: 8px;
  left: 8px;
  background: linear-gradient(135deg, #FF6B6B 0%, #FF8E53 100%);
  color: white;
  padding: 4px 10px;
  border-radius: 12px;
  font-size: 10px;
  font-weight: 600;
`;

const MatchInfo = styled.div`
  padding: 12px;
  text-align: center;
`;

const MatchName = styled.h3`
  font-size: 16px;
  font-weight: 600;
  color: #333;
  margin-bottom: 4px;
`;

const MatchDate = styled.p`
  font-size: 12px;
  color: #999;
`;

const ChatButton = styled.button`
  width: 100%;
  padding: 10px;
  background: linear-gradient(135deg, #FF6B6B 0%, #FF8E53 100%);
  color: white;
  border: none;
  border-radius: 10px;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
  margin-top: 10px;
  
  &:hover {
    opacity: 0.9;
  }
`;

const LikeItem = styled.div`
  background: white;
  border-radius: 16px;
  padding: 16px;
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 12px;
`;

const LikeAvatar = styled.img`
  width: 60px;
  height: 60px;
  border-radius: 50%;
  object-fit: cover;
`;

const LikeInfo = styled.div`
  flex: 1;
`;

const LikeName = styled.h3`
  font-size: 16px;
  font-weight: 600;
  color: #333;
`;

const LikeTime = styled.p`
  font-size: 12px;
  color: #999;
`;

const LikeButtons = styled.div`
  display: flex;
  gap: 8px;
`;

const LikeButton = styled.button`
  width: 40px;
  height: 40px;
  border-radius: 50%;
  border: none;
  font-size: 18px;
  cursor: pointer;
  transition: all 0.3s ease;
  
  &.like {
    background: #FF6B6B;
    color: white;
    
    &:hover {
      transform: scale(1.1);
    }
  }
  
  &.skip {
    background: #e0e0e0;
    color: #666;
    
    &:hover {
      background: #d0d0d0;
    }
  }
`;

const EmptyState = styled.div`
  text-align: center;
  color: white;
  padding: 60px 20px;
  
  h3 {
    font-size: 20px;
    margin-bottom: 8px;
  }
  
  p {
    font-size: 14px;
    opacity: 0.8;
  }
`;

const Matches = () => {
  const [activeTab, setActiveTab] = useState('matches');
  const [matches, setMatches] = useState([]);
  const [likes, setLikes] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [matchesRes, likesRes] = await Promise.all([
        axios.get('/matches'),
        axios.get('/matches/likes')
      ]);
      
      setMatches(matchesRes.data.matches || []);
      setLikes(likesRes.data.likes || []);
    } catch (error) {
      console.error('Fetch data error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleLikeBack = async (userId) => {
    try {
      await axios.post('/matches/swipe', {
        targetUserId: userId,
        action: 'like'
      });
      
      // Refresh data
      fetchData();
    } catch (error) {
      console.error('Like back error:', error);
    }
  };

  const handleSkip = async (userId) => {
    try {
      await axios.post('/matches/swipe', {
        targetUserId: userId,
        action: 'skip'
      });
      
      // Refresh data
      fetchData();
    } catch (error) {
      console.error('Skip error:', error);
    }
  };

  if (loading) {
    return <Container>Loading...</Container>;
  }

  return (
    <Container>
      <Title>Matches 💕</Title>
      
      <Tabs>
        <Tab 
          active={activeTab === 'matches'}
          onClick={() => setActiveTab('matches')}
        >
          Matches ({matches.length})
        </Tab>
        <Tab 
          active={activeTab === 'likes'}
          onClick={() => setActiveTab('likes')}
        >
          Likes ({likes.length})
        </Tab>
      </Tabs>

      {activeTab === 'matches' ? (
        matches.length === 0 ? (
          <EmptyState>
            <h3>Belum ada match 💔</h3>
            <p>Terus swipe untuk menemukan match!</p>
          </EmptyState>
        ) : (
          <MatchGrid>
            {matches.map((match) => (
              <MatchCard key={match._id}>
                <MatchImage onClick={() => navigate(`/user/${match.user?._id}`)}>
                  {match.user?.photos?.[0]?.url ? (
                    <img src={match.user.photos[0].url} alt={match.user.name} />
                  ) : (
                    <div style={{ 
                      display: 'flex', 
                      alignItems: 'center', 
                      justifyContent: 'center',
                      height: '100%',
                      fontSize: '50px'
                    }}>
                      👤
                    </div>
                  )}
                  {new Date(match.matchedAt) > new Date(Date.now() - 24 * 60 * 60 * 1000) && (
                    <NewMatchBadge>NEW MATCH</NewMatchBadge>
                  )}
                </MatchImage>
                
                <MatchInfo>
                  <MatchName>{match.user?.name}</MatchName>
                  <MatchDate>
                    Matched {new Date(match.matchedAt).toLocaleDateString('id-ID')}
                  </MatchDate>
                  <ChatButton onClick={() => navigate(`/chat/${match.chatRoom}`)}>
                    💬 Chat
                  </ChatButton>
                </MatchInfo>
              </MatchCard>
            ))}
          </MatchGrid>
        )
      ) : (
        likes.length === 0 ? (
          <EmptyState>
            <h3>Belum ada yang like kamu 😢</h3>
            <p>Tingkatkan profile-mu untuk menarik perhatian!</p>
          </EmptyState>
        ) : (
          <div>
            {likes.map((like) => (
              <LikeItem key={like._id}>
                {like.user?.photos?.[0]?.url ? (
                  <LikeAvatar 
                    src={like.user.photos[0].url} 
                    alt={like.user.name}
                    onClick={() => navigate(`/user/${like.user._id}`)}
                    style={{ cursor: 'pointer' }}
                  />
                ) : (
                  <div 
                    style={{ 
                      width: 60, 
                      height: 60, 
                      borderRadius: '50%',
                      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontSize: '30px'
                    }}
                    onClick={() => navigate(`/user/${like.user._id}`)}
                  >
                    👤
                  </div>
                )}
                
                <LikeInfo>
                  <LikeName>{like.user?.name}</LikeName>
                  <LikeTime>
                    {new Date(like.createdAt).toLocaleDateString('id-ID')}
                  </LikeTime>
                </LikeInfo>
                
                <LikeButtons>
                  <LikeButton 
                    className="skip"
                    onClick={() => handleSkip(like.user?._id)}
                  >
                    ❌
                  </LikeButton>
                  <LikeButton 
                    className="like"
                    onClick={() => handleLikeBack(like.user?._id)}
                  >
                    ❤️
                  </LikeButton>
                </LikeButtons>
              </LikeItem>
            ))}
          </div>
        )
      )}
    </Container>
  );
};

export default Matches;
