import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import styled from 'styled-components';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';

const Container = styled.div`
  padding: 16px;
  max-width: 500px;
  margin: 0 auto;
`;

const Title = styled.h1`
  font-size: 24px;
  font-weight: 700;
  color: white;
  margin-bottom: 20px;
`;

const Form = styled.form`
  background: white;
  border-radius: 20px;
  padding: 24px;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
`;

const PhotoSection = styled.div`
  text-align: center;
  margin-bottom: 24px;
`;

const PhotoGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 10px;
  margin-top: 16px;
`;

const PhotoItem = styled.div`
  aspect-ratio: 1;
  border-radius: 12px;
  overflow: hidden;
  position: relative;
  background: #f0f0f0;
  
  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
`;

const AddPhotoButton = styled.button`
  width: 100%;
  height: 100%;
  border: 2px dashed #ccc;
  border-radius: 12px;
  background: none;
  font-size: 30px;
  color: #999;
  cursor: pointer;
  
  &:hover {
    border-color: #FF6B6B;
    color: #FF6B6B;
  }
`;

const DeletePhotoButton = styled.button`
  position: absolute;
  top: 4px;
  right: 4px;
  background: rgba(255, 0, 0, 0.8);
  color: white;
  border: none;
  width: 24px;
  height: 24px;
  border-radius: 50%;
  font-size: 14px;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
`;

const InputGroup = styled.div`
  margin-bottom: 20px;
`;

const Label = styled.label`
  display: block;
  font-size: 14px;
  font-weight: 500;
  color: #333;
  margin-bottom: 8px;
`;

const Input = styled.input`
  width: 100%;
  padding: 14px;
  border: 2px solid #e0e0e0;
  border-radius: 12px;
  font-size: 15px;
  transition: all 0.3s ease;
  
  &:focus {
    outline: none;
    border-color: #FF6B6B;
  }
`;

const TextArea = styled.textarea`
  width: 100%;
  padding: 14px;
  border: 2px solid #e0e0e0;
  border-radius: 12px;
  font-size: 15px;
  min-height: 100px;
  resize: vertical;
  font-family: inherit;
  transition: all 0.3s ease;
  
  &:focus {
    outline: none;
    border-color: #FF6B6B;
  }
`;

const Select = styled.select`
  width: 100%;
  padding: 14px;
  border: 2px solid #e0e0e0;
  border-radius: 12px;
  font-size: 15px;
  background: white;
  transition: all 0.3s ease;
  
  &:focus {
    outline: none;
    border-color: #FF6B6B;
  }
`;

const ButtonGroup = styled.div`
  display: flex;
  gap: 12px;
  margin-top: 24px;
`;

const Button = styled.button`
  flex: 1;
  padding: 16px;
  border: none;
  border-radius: 12px;
  font-size: 16px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
  
  &.primary {
    background: linear-gradient(135deg, #FF6B6B 0%, #FF8E53 100%);
    color: white;
    
    &:hover {
      transform: translateY(-2px);
      box-shadow: 0 8px 20px rgba(255, 107, 107, 0.4);
    }
  }
  
  &.secondary {
    background: #e0e0e0;
    color: #666;
    
    &:hover {
      background: #d0d0d0;
    }
  }
`;

const EditProfile = () => {
  const { user, updateProfile } = useAuth();
  const navigate = useNavigate();
  
  const [formData, setFormData] = useState({
    name: user?.name || '',
    age: user?.age || '',
    bio: user?.bio || '',
    city: user?.city || '',
    gender: user?.gender || ''
  });
  const [photos, setPhotos] = useState(user?.photos || []);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    const result = await updateProfile({
      ...formData,
      age: parseInt(formData.age)
    });
    
    if (result.success) {
      navigate('/profile');
    } else {
      alert(result.message);
    }
  };

  const handlePhotoUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const formData = new FormData();
    formData.append('photo', file);

    try {
      const response = await axios.post('/users/photos', formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
      setPhotos(response.data.photos);
    } catch (error) {
      alert('Gagal upload foto');
    }
  };

  const handleDeletePhoto = async (photoId) => {
    try {
      await axios.delete(`/users/photos/${photoId}`);
      setPhotos(photos.filter(p => p._id !== photoId));
    } catch (error) {
      alert('Gagal hapus foto');
    }
  };

  return (
    <Container>
      <Title>Edit Profil ✏️</Title>
      
      <Form onSubmit={handleSubmit}>
        <PhotoSection>
          <Label>Foto</Label>
          <PhotoGrid>
            {photos.map((photo) => (
              <PhotoItem key={photo._id}>
                <img src={photo.url} alt="Profile" />
                <DeletePhotoButton 
                  type="button"
                  onClick={() => handleDeletePhoto(photo._id)}
                >
                  ×
                </DeletePhotoButton>
              </PhotoItem>
            ))}
            <PhotoItem>
              <label>
                <AddPhotoButton type="button">+</AddPhotoButton>
                <input
                  type="file"
                  accept="image/*"
                  style={{ display: 'none' }}
                  onChange={handlePhotoUpload}
                />
              </label>
            </PhotoItem>
          </PhotoGrid>
        </PhotoSection>

        <InputGroup>
          <Label>Nama</Label>
          <Input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleChange}
            required
          />
        </InputGroup>

        <InputGroup>
          <Label>Umur</Label>
          <Input
            type="number"
            name="age"
            value={formData.age}
            onChange={handleChange}
            min={18}
            max={100}
          />
        </InputGroup>

        <InputGroup>
          <Label>Gender</Label>
          <Select
            name="gender"
            value={formData.gender}
            onChange={handleChange}
          >
            <option value="">Pilih Gender</option>
            <option value="male">Laki-laki</option>
            <option value="female">Perempuan</option>
            <option value="other">Lainnya</option>
            <option value="prefer_not_to_say">Rahasia</option>
          </Select>
        </InputGroup>

        <InputGroup>
          <Label>Kota</Label>
          <Input
            type="text"
            name="city"
            value={formData.city}
            onChange={handleChange}
          />
        </InputGroup>

        <InputGroup>
          <Label>Bio</Label>
          <TextArea
            name="bio"
            value={formData.bio}
            onChange={handleChange}
            placeholder="Ceritakan tentang dirimu..."
            maxLength={500}
          />
        </InputGroup>

        <ButtonGroup>
          <Button 
            type="button" 
            className="secondary"
            onClick={() => navigate('/profile')}
          >
            Batal
          </Button>
          <Button type="submit" className="primary">
            Simpan
          </Button>
        </ButtonGroup>
      </Form>
    </Container>
  );
};

export default EditProfile;
