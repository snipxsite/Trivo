import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import styled from 'styled-components';
import axios from 'axios';

const Container = styled.div`
  padding: 16px;
`;

const Title = styled.h1`
  font-size: 24px;
  font-weight: 700;
  color: white;
  margin-bottom: 20px;
`;

const FilterSection = styled.div`
  display: flex;
  gap: 10px;
  margin-bottom: 20px;
  overflow-x: auto;
  padding-bottom: 8px;
  
  &::-webkit-scrollbar {
    display: none;
  }
`;

const FilterChip = styled.button`
  padding: 10px 18px;
  background: ${props => props.active ? 'white' : 'rgba(255, 255, 255, 0.2)'};
  color: ${props => props.active ? '#FF6B6B' : 'white'};
  border: none;
  border-radius: 25px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  white-space: nowrap;
  transition: all 0.3s ease;
  
  &:hover {
    background: white;
    color: #FF6B6B;
  }
`;

const SearchBar = styled.div`
  display: flex;
  align-items: center;
  background: white;
  border-radius: 12px;
  padding: 12px 16px;
  margin-bottom: 20px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
`;

const SearchInput = styled.input`
  flex: 1;
  border: none;
  outline: none;
  font-size: 15px;
  margin-left: 10px;
  
  &::placeholder {
    color: #999;
  }
`;

const UserGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 12px;
`;

const UserCard = styled.div`
  background: white;
  border-radius: 16px;
  overflow: hidden;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
  cursor: pointer;
  transition: transform 0.3s ease;
  
  &:hover {
    transform: translateY(-3px);
  }
`;

const CardImage = styled.div`
  height: 160px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  position: relative;
  
  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
`;

const OnlineIndicator = styled.div`
  position: absolute;
  top: 8px;
  right: 8px;
  width: 12px;
  height: 12px;
  background: #4CAF50;
  border-radius: 50%;
  border: 2px solid white;
`;

const VerifiedBadge = styled.div`
  position: absolute;
  bottom: 8px;
  right: 8px;
  background: #2196F3;
  color: white;
  width: 24px;
  height: 24px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 12px;
`;

const CardInfo = styled.div`
  padding: 12px;
`;

const CardName = styled.h3`
  font-size: 15px;
  font-weight: 600;
  color: #333;
  margin-bottom: 4px;
`;

const CardDetails = styled.p`
  font-size: 12px;
  color: #666;
`;

const Interests = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
  margin-top: 8px;
`;

const InterestTag = styled.span`
  background: #f0f0f0;
  color: #666;
  padding: 3px 8px;
  border-radius: 10px;
  font-size: 10px;
`;

const EmptyState = styled.div`
  text-align: center;
  color: white;
  padding: 60px 20px;
  
  h3 {
    font-size: 20px;
    margin-bottom: 8px;
  }
  
  p {
    font-size: 14px;
    opacity: 0.8;
  }
`;

const Explore = () => {
  const [users, setUsers] = useState([]);
  const [filter, setFilter] = useState('all');
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    fetchUsers();
  }, [filter]);

  const fetchUsers = async () => {
    try {
      let url = '/users/explore';
      if (filter !== 'all') {
        url += `?gender=${filter}`;
      }
      
      const response = await axios.get(url);
      setUsers(response.data.users || []);
    } catch (error) {
      console.error('Fetch users error:', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredUsers = users.filter(user =>
    user.name.toLowerCase().includes(search.toLowerCase()) ||
    user.city?.toLowerCase().includes(search.toLowerCase())
  );

  if (loading) {
    return <Container>Loading...</Container>;
  }

  return (
    <Container>
      <Title>Jelajahi 🔍</Title>
      
      <SearchBar>
        <span>🔍</span>
        <SearchInput
          type="text"
          placeholder="Cari nama atau kota..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </SearchBar>

      <FilterSection>
        <FilterChip 
          active={filter === 'all'}
          onClick={() => setFilter('all')}
        >
          Semua
        </FilterChip>
        <FilterChip 
          active={filter === 'male'}
          onClick={() => setFilter('male')}
        >
          Laki-laki
        </FilterChip>
        <FilterChip 
          active={filter === 'female'}
          onClick={() => setFilter('female')}
        >
          Perempuan
        </FilterChip>
        <FilterChip 
          active={filter === 'online'}
          onClick={() => setFilter('online')}
        >
          Online
        </FilterChip>
      </FilterSection>

      {filteredUsers.length === 0 ? (
        <EmptyState>
          <h3>Tidak ada user ditemukan</h3>
          <p>Coba ubah filter atau kata kunci pencarian</p>
        </EmptyState>
      ) : (
        <UserGrid>
          {filteredUsers.map((user) => (
            <UserCard 
              key={user._id}
              onClick={() => navigate(`/user/${user._id}`)}
            >
              <CardImage>
                {user.photos?.[0]?.url ? (
                  <img src={user.photos[0].url} alt={user.name} />
                ) : (
                  <div style={{ 
                    display: 'flex', 
                    alignItems: 'center', 
                    justifyContent: 'center',
                    height: '100%',
                    fontSize: '50px'
                  }}>
                    👤
                  </div>
                )}
                {user.isOnline && <OnlineIndicator />}
                {user.isVerified && <VerifiedBadge>✓</VerifiedBadge>}
              </CardImage>
              
              <CardInfo>
                <CardName>{user.name}, {user.age}</CardName>
                <CardDetails>{user.city || 'Unknown location'}</CardDetails>
                
                {user.interests && user.interests.length > 0 && (
                  <Interests>
                    {user.interests.slice(0, 3).map((interest, idx) => (
                      <InterestTag key={idx}>{interest}</InterestTag>
                    ))}
                  </Interests>
                )}
              </CardInfo>
            </UserCard>
          ))}
        </UserGrid>
      )}
    </Container>
  );
};

export default Explore;
