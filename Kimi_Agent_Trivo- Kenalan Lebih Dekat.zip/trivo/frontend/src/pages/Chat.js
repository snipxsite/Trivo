import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import styled from 'styled-components';
import axios from 'axios';
import { useSocket } from '../context/SocketContext';

const Container = styled.div`
  padding: 16px;
`;

const Header = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
`;

const Title = styled.h1`
  font-size: 24px;
  font-weight: 700;
  color: white;
`;

const NewChatButton = styled.button`
  background: white;
  border: none;
  width: 40px;
  height: 40px;
  border-radius: 50%;
  font-size: 20px;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  
  &:hover {
    transform: scale(1.05);
  }
`;

const ChatList = styled.div`
  display: flex;
  flex-direction: column;
  gap: 12px;
`;

const ChatItem = styled.div`
  background: white;
  border-radius: 16px;
  padding: 16px;
  display: flex;
  align-items: center;
  gap: 12px;
  cursor: pointer;
  transition: all 0.3s ease;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  
  &:hover {
    transform: translateX(5px);
  }
`;

const Avatar = styled.img`
  width: 56px;
  height: 56px;
  border-radius: 50%;
  object-fit: cover;
`;

const DefaultAvatar = styled.div`
  width: 56px;
  height: 56px;
  border-radius: 50%;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 28px;
`;

const AvatarContainer = styled.div`
  position: relative;
`;

const OnlineIndicator = styled.div`
  position: absolute;
  bottom: 2px;
  right: 2px;
  width: 14px;
  height: 14px;
  background: #4CAF50;
  border-radius: 50%;
  border: 2px solid white;
`;

const ChatInfo = styled.div`
  flex: 1;
  min-width: 0;
`;

const ChatHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 4px;
`;

const ChatName = styled.h3`
  font-size: 16px;
  font-weight: 600;
  color: #333;
`;

const ChatTime = styled.span`
  font-size: 12px;
  color: #999;
`;

const LastMessage = styled.p`
  font-size: 14px;
  color: #666;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
`;

const UnreadBadge = styled.div`
  background: #FF6B6B;
  color: white;
  font-size: 12px;
  font-weight: 600;
  min-width: 22px;
  height: 22px;
  border-radius: 11px;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 0 6px;
`;

const ReadStatus = styled.span`
  font-size: 12px;
  color: ${props => props.read ? '#4CAF50' : '#999'};
  margin-right: 4px;
`;

const EmptyState = styled.div`
  text-align: center;
  color: white;
  padding: 60px 20px;
  
  h3 {
    font-size: 20px;
    margin-bottom: 8px;
  }
  
  p {
    font-size: 14px;
    opacity: 0.8;
    margin-bottom: 20px;
  }
`;

const ExploreButton = styled.button`
  background: white;
  color: #FF6B6B;
  border: none;
  padding: 14px 28px;
  border-radius: 25px;
  font-size: 16px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
  
  &:hover {
    transform: scale(1.05);
    box-shadow: 0 5px 20px rgba(255, 107, 107, 0.4);
  }
`;

const Chat = () => {
  const [rooms, setRooms] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const { onEvent, offEvent } = useSocket();

  useEffect(() => {
    fetchChatRooms();
  }, []);

  useEffect(() => {
    // Listen for new messages
    const handleNewMessage = (data) => {
      fetchChatRooms();
    };

    onEvent('new_message', handleNewMessage);

    return () => {
      offEvent('new_message', handleNewMessage);
    };
  }, [onEvent, offEvent]);

  const fetchChatRooms = async () => {
    try {
      const response = await axios.get('/chats/rooms');
      setRooms(response.data.rooms || []);
    } catch (error) {
      console.error('Fetch chat rooms error:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatTime = (date) => {
    if (!date) return '';
    const messageDate = new Date(date);
    const now = new Date();
    const diff = now - messageDate;
    
    if (diff < 60000) return 'Just now';
    if (diff < 3600000) return `${Math.floor(diff / 60000)}m`;
    if (diff < 86400000) return `${Math.floor(diff / 3600000)}h`;
    return `${Math.floor(diff / 86400000)}d`;
  };

  if (loading) {
    return <Container>Loading...</Container>;
  }

  if (rooms.length === 0) {
    return (
      <Container>
        <EmptyState>
          <h3>Belum ada chat 💬</h3>
          <p>Mulai chat dengan match-mu!</p>
          <ExploreButton onClick={() => navigate('/explore')}>
            Jelajahi
          </ExploreButton>
        </EmptyState>
      </Container>
    );
  }

  return (
    <Container>
      <Header>
        <Title>Pesan 💬</Title>
        <NewChatButton onClick={() => navigate('/matches')}>
          ✏️
        </NewChatButton>
      </Header>

      <ChatList>
        {rooms.map((room) => (
          <ChatItem 
            key={room._id}
            onClick={() => navigate(`/chat/${room.roomId}`)}
          >
            <AvatarContainer>
              {room.user?.photos?.[0]?.url ? (
                <Avatar src={room.user.photos[0].url} alt={room.user.name} />
              ) : (
                <DefaultAvatar>👤</DefaultAvatar>
              )}
              {room.user?.isOnline && <OnlineIndicator />}
            </AvatarContainer>

            <ChatInfo>
              <ChatHeader>
                <ChatName>{room.user?.name}</ChatName>
                {room.lastMessage && (
                  <ChatTime>{formatTime(room.lastMessage.sentAt)}</ChatTime>
                )}
              </ChatHeader>
              
              {room.lastMessage ? (
                <LastMessage>
                  <ReadStatus read={room.lastMessage.status === 'read'}>
                    {room.lastMessage.sender?._id === room.user?._id ? '' : '✓'}
                  </ReadStatus>
                  {room.lastMessage.text}
                </LastMessage>
              ) : (
                <LastMessage style={{ color: '#999', fontStyle: 'italic' }}>
                  Belum ada pesan
                </LastMessage>
              )}
            </ChatInfo>

            {room.unreadCount > 0 && (
              <UnreadBadge>{room.unreadCount}</UnreadBadge>
            )}
          </ChatItem>
        ))}
      </ChatList>
    </Container>
  );
};

export default Chat;
