import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import styled from 'styled-components';
import { useAuth } from './context/AuthContext';

// Pages
import Login from './pages/Login';
import Register from './pages/Register';
import Home from './pages/Home';
import Explore from './pages/Explore';
import Live from './pages/Live';
import Chat from './pages/Chat';
import ChatRoom from './pages/ChatRoom';
import Profile from './pages/Profile';
import EditProfile from './pages/EditProfile';
import UserProfile from './pages/UserProfile';
import Matches from './pages/Matches';
import Stories from './pages/Stories';
import Nearby from './pages/Nearby';

// Components
import BottomNav from './components/BottomNav';
import TopBar from './components/TopBar';

const AppContainer = styled.div`
  min-height: 100vh;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  display: flex;
  flex-direction: column;
`;

const MainContent = styled.main`
  flex: 1;
  padding-bottom: 70px; /* Space for bottom nav */
  overflow-y: auto;
`;

const ProtectedLayout = ({ children }) => {
  const { isAuthenticated, loading } = useAuth();

  if (loading) {
    return (
      <div style={{ 
        display: 'flex', 
        justifyContent: 'center', 
        alignItems: 'center', 
        height: '100vh',
        color: 'white'
      }}>
        Loading...
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  return (
    <>
      <TopBar />
      <MainContent>{children}</MainContent>
      <BottomNav />
    </>
  );
};

const PublicLayout = ({ children }) => {
  const { isAuthenticated, loading } = useAuth();

  if (loading) {
    return (
      <div style={{ 
        display: 'flex', 
        justifyContent: 'center', 
        alignItems: 'center', 
        height: '100vh',
        color: 'white'
      }}>
        Loading...
      </div>
    );
  }

  if (isAuthenticated) {
    return <Navigate to="/" replace />;
  }

  return children;
};

function App() {
  return (
    <AppContainer>
      <Routes>
        {/* Public Routes */}
        <Route 
          path="/login" 
          element={
            <PublicLayout>
              <Login />
            </PublicLayout>
          } 
        />
        <Route 
          path="/register" 
          element={
            <PublicLayout>
              <Register />
            </PublicLayout>
          } 
        />

        {/* Protected Routes */}
        <Route 
          path="/" 
          element={
            <ProtectedLayout>
              <Home />
            </ProtectedLayout>
          } 
        />
        <Route 
          path="/explore" 
          element={
            <ProtectedLayout>
              <Explore />
            </ProtectedLayout>
          } 
        />
        <Route 
          path="/live" 
          element={
            <ProtectedLayout>
              <Live />
            </ProtectedLayout>
          } 
        />
        <Route 
          path="/chat" 
          element={
            <ProtectedLayout>
              <Chat />
            </ProtectedLayout>
          } 
        />
        <Route 
          path="/chat/:roomId" 
          element={
            <ProtectedLayout>
              <ChatRoom />
            </ProtectedLayout>
          } 
        />
        <Route 
          path="/profile" 
          element={
            <ProtectedLayout>
              <Profile />
            </ProtectedLayout>
          } 
        />
        <Route 
          path="/profile/edit" 
          element={
            <ProtectedLayout>
              <EditProfile />
            </ProtectedLayout>
          } 
        />
        <Route 
          path="/user/:userId" 
          element={
            <ProtectedLayout>
              <UserProfile />
            </ProtectedLayout>
          } 
        />
        <Route 
          path="/matches" 
          element={
            <ProtectedLayout>
              <Matches />
            </ProtectedLayout>
          } 
        />
        <Route 
          path="/stories" 
          element={
            <ProtectedLayout>
              <Stories />
            </ProtectedLayout>
          } 
        />
        <Route 
          path="/nearby" 
          element={
            <ProtectedLayout>
              <Nearby />
            </ProtectedLayout>
          } 
        />

        {/* Catch all */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </AppContainer>
  );
}

export default App;
