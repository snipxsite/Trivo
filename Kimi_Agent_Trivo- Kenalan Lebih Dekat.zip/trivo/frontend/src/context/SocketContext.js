import React, { createContext, useContext, useEffect, useState } from 'react';
import { io } from 'socket.io-client';
import { useAuth } from './AuthContext';

const SocketContext = createContext();

export const useSocket = () => useContext(SocketContext);

const SOCKET_URL = process.env.REACT_APP_SOCKET_URL || 'http://localhost:5000';

export const SocketProvider = ({ children }) => {
  const [socket, setSocket] = useState(null);
  const [isConnected, setIsConnected] = useState(false);
  const { user, token } = useAuth();

  useEffect(() => {
    if (user && token) {
      // Create socket connection
      const newSocket = io(SOCKET_URL, {
        transports: ['websocket'],
        autoConnect: true
      });

      newSocket.on('connect', () => {
        console.log('Socket connected');
        setIsConnected(true);
        
        // Authenticate socket
        newSocket.emit('authenticate', { userId: user.id });
      });

      newSocket.on('disconnect', () => {
        console.log('Socket disconnected');
        setIsConnected(false);
      });

      newSocket.on('authenticated', (data) => {
        console.log('Socket authenticated:', data);
      });

      newSocket.on('auth_error', (error) => {
        console.error('Socket auth error:', error);
      });

      setSocket(newSocket);

      return () => {
        newSocket.close();
      };
    }
  }, [user, token]);

  // Join a chat room
  const joinRoom = (roomId) => {
    if (socket) {
      socket.emit('join_room', { roomId });
    }
  };

  // Leave a chat room
  const leaveRoom = (roomId) => {
    if (socket) {
      socket.emit('leave_room', { roomId });
    }
  };

  // Send typing indicator
  const sendTyping = (roomId, isTyping) => {
    if (socket) {
      socket.emit('typing', { roomId, isTyping });
    }
  };

  // Mark message as read
  const markMessageRead = (messageId) => {
    if (socket) {
      socket.emit('message_read', { messageId });
    }
  };

  // Join live stream
  const joinStream = (streamId) => {
    if (socket) {
      socket.emit('join_stream', { streamId });
    }
  };

  // Leave live stream
  const leaveStream = (streamId) => {
    if (socket) {
      socket.emit('leave_stream', { streamId });
    }
  };

  // Send stream like
  const sendStreamLike = (streamId) => {
    if (socket) {
      socket.emit('stream_like', { streamId });
    }
  };

  // Listen to events
  const onEvent = (event, callback) => {
    if (socket) {
      socket.on(event, callback);
    }
  };

  // Remove event listener
  const offEvent = (event, callback) => {
    if (socket) {
      socket.off(event, callback);
    }
  };

  const value = {
    socket,
    isConnected,
    joinRoom,
    leaveRoom,
    sendTyping,
    markMessageRead,
    joinStream,
    leaveStream,
    sendStreamLike,
    onEvent,
    offEvent
  };

  return (
    <SocketContext.Provider value={value}>
      {children}
    </SocketContext.Provider>
  );
};
