import React from 'react';
import { useNavigate } from 'react-router-dom';
import styled from 'styled-components';
import { useAuth } from '../context/AuthContext';

const TopBarContainer = styled.header`
  position: sticky;
  top: 0;
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  padding: 12px 16px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  z-index: 100;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
`;

const Logo = styled.div`
  display: flex;
  align-items: center;
  gap: 8px;
  cursor: pointer;
`;

const LogoIcon = styled.div`
  width: 35px;
  height: 35px;
  background: linear-gradient(135deg, #FF6B6B 0%, #FF8E53 100%);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 18px;
`;

const LogoText = styled.h1`
  font-size: 20px;
  font-weight: 700;
  background: linear-gradient(135deg, #FF6B6B 0%, #FF8E53 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
`;

const Actions = styled.div`
  display: flex;
  gap: 12px;
  align-items: center;
`;

const ActionButton = styled.button`
  background: none;
  border: none;
  font-size: 22px;
  cursor: pointer;
  padding: 5px;
  border-radius: 50%;
  transition: all 0.3s ease;
  position: relative;
  
  &:hover {
    background: rgba(255, 107, 107, 0.1);
  }
`;

const NotificationBadge = styled.span`
  position: absolute;
  top: 0;
  right: 0;
  background: #ff0000;
  color: white;
  font-size: 10px;
  font-weight: 600;
  padding: 2px 5px;
  border-radius: 10px;
  min-width: 16px;
  text-align: center;
`;

const UserAvatar = styled.img`
  width: 32px;
  height: 32px;
  border-radius: 50%;
  object-fit: cover;
  border: 2px solid #FF6B6B;
  cursor: pointer;
`;

const TopBar = () => {
  const navigate = useNavigate();
  const { user } = useAuth();

  return (
    <TopBarContainer>
      <Logo onClick={() => navigate('/')}>
        <LogoIcon>💝</LogoIcon>
        <LogoText>Trivo</LogoText>
      </Logo>
      
      <Actions>
        <ActionButton onClick={() => navigate('/matches')}>
          🔔
          <NotificationBadge>3</NotificationBadge>
        </ActionButton>
        
        <ActionButton onClick={() => navigate('/stories')}>
          📸
        </ActionButton>
        
        {user?.photos?.[0]?.url ? (
          <UserAvatar 
            src={user.photos[0].url} 
            alt={user.name}
            onClick={() => navigate('/profile')}
          />
        ) : (
          <ActionButton onClick={() => navigate('/profile')}>
            👤
          </ActionButton>
        )}
      </Actions>
    </TopBarContainer>
  );
};

export default TopBar;
