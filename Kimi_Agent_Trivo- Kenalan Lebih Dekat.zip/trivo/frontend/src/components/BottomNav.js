import React from 'react';
import { NavLink } from 'react-router-dom';
import styled from 'styled-components';

const NavContainer = styled.nav`
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  background: white;
  display: flex;
  justify-content: space-around;
  align-items: center;
  padding: 8px 0;
  box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.1);
  z-index: 1000;
  border-top-left-radius: 20px;
  border-top-right-radius: 20px;
`;

const NavItem = styled(NavLink)`
  display: flex;
  flex-direction: column;
  align-items: center;
  text-decoration: none;
  color: #999;
  padding: 5px 15px;
  transition: all 0.3s ease;
  
  &.active {
    color: #FF6B6B;
  }
  
  &:hover {
    color: #FF6B6B;
  }
`;

const Icon = styled.span`
  font-size: 24px;
  margin-bottom: 2px;
`;

const Label = styled.span`
  font-size: 10px;
  font-weight: 500;
`;

const LiveIndicator = styled.span`
  position: absolute;
  top: 5px;
  right: 5px;
  width: 8px;
  height: 8px;
  background: #ff0000;
  border-radius: 50%;
  animation: pulse 1.5s infinite;
  
  @keyframes pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.5; }
  }
`;

const BottomNav = () => {
  return (
    <NavContainer>
      <NavItem to="/" end>
        <Icon>🏠</Icon>
        <Label>Home</Label>
      </NavItem>
      
      <NavItem to="/explore">
        <Icon>🔍</Icon>
        <Label>Explore</Label>
      </NavItem>
      
      <NavItem to="/live" style={{ position: 'relative' }}>
        <Icon>🔴</Icon>
        <Label>Live</Label>
        <LiveIndicator />
      </NavItem>
      
      <NavItem to="/chat">
        <Icon>💬</Icon>
        <Label>Chat</Label>
      </NavItem>
      
      <NavItem to="/profile">
        <Icon>👤</Icon>
        <Label>Profile</Label>
      </NavItem>
    </NavContainer>
  );
};

export default BottomNav;
