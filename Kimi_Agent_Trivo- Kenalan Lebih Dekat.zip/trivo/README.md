# Trivo - Aplikasi Dating

**Trivo** adalah aplikasi dating lengkap dengan fitur-fitur modern seperti Tinder dan Hornet. Slogan: *"Kenalan lebih dekat, mulai dari sekitar"*

## Fitur Utama

### Profil Pengguna
- Foto profil multiple
- Nama, umur, bio, kota
- Gender preference

### Grid Pengguna Sekitar
- Menampilkan orang di sekitar dengan foto dan jarak
- GPS lokasi dengan radius: 1km, 5km, 10km
- Status online (titik hijau)

### Swipe / Like
- Swipe kanan = Like ❤️
- Swipe kiri = Skip ❌
- Match jika dua orang saling like

### Chat
- Real-time chat dengan Socket.io
- Kirim pesan, emoji, foto
- Notifikasi pesan baru
- Seen message (✓✓)

### Story
- Story 24 jam
- Photo dan text stories
- Views dan reactions

### Live Streaming
- User bisa live streaming
- Viewer bisa join dan chat
- Gift system

### Explore
- Search user
- Filter (umur, jarak, gender)
- Trending users

## Struktur Project

```
trivo/
├── backend/                 # Backend API (Node.js + Express)
│   ├── config/             # Konfigurasi database
│   ├── middleware/         # Auth & upload middleware
│   ├── models/             # MongoDB models
│   ├── routes/             # API routes
│   ├── socket/             # Socket.io handler
│   ├── uploads/            # Upload folder
│   ├── server.js           # Main server file
│   └── package.json
│
├── frontend/                # Frontend (React)
│   ├── public/             # Static files
│   ├── src/
│   │   ├── components/     # Reusable components
│   │   ├── context/        # React context (Auth, Socket)
│   │   ├── pages/          # Page components
│   │   ├── App.js          # Main App
│   │   └── index.js        # Entry point
│   └── package.json
│
└── README.md
```

## Cara Install di Termux

### 1. Install Termux dari F-Droid
Download Termux dari [F-Droid](https://f-droid.org/packages/com.termux/)

### 2. Update & Install Dependencies
```bash
pkg update && pkg upgrade
pkg install nodejs mongodb git
```

### 3. Clone Project
```bash
cd ~
# Copy project folder ke Termux
# atau download zip dan extract
```

### 4. Setup Backend
```bash
cd trivo/backend
npm install

# Start MongoDB
mkdir -p ~/data/db
mongod --dbpath ~/data/db &

# Jalankan backend
npm start
```

Backend akan berjalan di `http://localhost:5000`

### 5. Setup Frontend (New Terminal)
```bash
cd trivo/frontend
npm install
npm start
```

Frontend akan berjalan di `http://localhost:3000`

## API Endpoints

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login user
- `POST /api/auth/logout` - Logout user
- `GET /api/auth/me` - Get current user
- `PUT /api/auth/location` - Update location

### Users
- `GET /api/users` - Get all users
- `GET /api/users/nearby` - Get nearby users
- `GET /api/users/explore` - Get users for swipe
- `GET /api/users/:id` - Get user profile
- `PUT /api/users/profile` - Update profile
- `POST /api/users/avatar` - Upload avatar
- `POST /api/users/photos` - Upload photos

### Matches
- `POST /api/matches/swipe` - Swipe like/skip
- `GET /api/matches` - Get all matches
- `GET /api/matches/likes` - Get likes
- `DELETE /api/matches/:id` - Unmatch
- `POST /api/matches/:id/superlike` - Super like

### Chat
- `GET /api/chats/rooms` - Get chat rooms
- `GET /api/chats/:roomId/messages` - Get messages
- `POST /api/chats/:roomId/messages` - Send message
- `PUT /api/chats/messages/:id/read` - Mark as read

### Stories
- `GET /api/stories` - Get all stories
- `GET /api/stories/my` - Get my stories
- `POST /api/stories` - Create story
- `POST /api/stories/:id/view` - View story
- `POST /api/stories/:id/react` - React to story

### Live
- `GET /api/live` - Get live streams
- `POST /api/live/start` - Start live
- `POST /api/live/:id/end` - End live
- `POST /api/live/:id/join` - Join live
- `POST /api/live/:id/comment` - Send comment
- `POST /api/live/:id/gift` - Send gift

## Database Schema

### User
```javascript
{
  email: String,
  password: String,
  name: String,
  age: Number,
  gender: String,
  bio: String,
  city: String,
  photos: Array,
  location: { type: 'Point', coordinates: [longitude, latitude] },
  preferences: {
    lookingFor: String,
    ageRange: { min: Number, max: Number },
    distance: Number
  },
  isOnline: Boolean,
  isPremium: Boolean,
  stats: {
    likesReceived: Number,
    likesGiven: Number,
    matches: Number,
    profileViews: Number
  }
}
```

### Match
```javascript
{
  users: [ObjectId],
  initiator: ObjectId,
  status: String, // 'pending', 'matched', 'unmatched'
  matchedAt: Date,
  chatRoom: String
}
```

### Message
```javascript
{
  chatRoom: String,
  sender: ObjectId,
  receiver: ObjectId,
  content: String,
  messageType: String, // 'text', 'image', 'emoji'
  status: String, // 'sent', 'delivered', 'read'
  readAt: Date
}
```

### Story
```javascript
{
  user: ObjectId,
  mediaUrl: String,
  mediaType: String,
  caption: String,
  views: Array,
  reactions: Array,
  expiresAt: Date
}
```

### LiveStream
```javascript
{
  streamer: ObjectId,
  title: String,
  streamKey: String,
  viewers: Array,
  viewerCount: Number,
  gifts: Array,
  comments: Array,
  status: String, // 'live', 'ended'
  startedAt: Date
}
```

## Environment Variables

### Backend (.env)
```
PORT=5000
MONGODB_URI=mongodb://127.0.0.1:27017/trivo
JWT_SECRET=your_secret_key
JWT_EXPIRE=30d
NODE_ENV=development
```

### Frontend (.env)
```
REACT_APP_API_URL=http://localhost:5000/api
REACT_APP_SOCKET_URL=http://localhost:5000
```

## Monetisasi

1. **Premium Membership** - Fitur eksklusif unlimited likes, see who liked you, dll
2. **Boost Profile** - Muncul di urutan teratas
3. **Iklan** - Tampilkan iklan untuk user gratis
4. **Gift saat Live** - Virtual gifts dengan pembelian coins

## Menu Aplikasi

1. 🏠 **Home** - Dashboard dengan stories dan nearby users
2. 🔍 **Explore** - Cari dan filter user
3. 🔴 **Live** - Live streaming
4. 💬 **Chat** - Daftar chat dan pesan
5. 👤 **Profile** - Profil dan pengaturan

## Teknologi

- **Backend**: Node.js, Express, MongoDB, Socket.io
- **Frontend**: React, Styled Components
- **Real-time**: Socket.io
- **Geolocation**: MongoDB Geospatial Queries
- **Upload**: Multer
- **Auth**: JWT

## Lisensi

MIT License

## Kontak

Untuk pertanyaan dan saran, silakan hubungi kami.

---

**Trivo** - Kenalan lebih dekat, mulai dari sekitar 💝
