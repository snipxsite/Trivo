#!/bin/bash

echo "=========================================="
echo "  Trivo Dating App - Termux Setup"
echo "  Kenalan lebih dekat, mulai dari sekitar"
echo "=========================================="
echo ""

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check if running in Termux
if [ -z "$TERMUX_VERSION" ] && [ -z "$TERMUX_API_VERSION" ]; then
    echo -e "${YELLOW}Warning: Not running in Termux environment${NC}"
    echo "This script is designed for Termux on Android"
    echo ""
fi

# Update packages
echo -e "${YELLOW}[1/8] Updating packages...${NC}"
apt update && apt upgrade -y

# Install required packages
echo -e "${YELLOW}[2/8] Installing required packages...${NC}"
pkg install -y nodejs mongodb git curl wget

# Check if installation successful
if [ $? -ne 0 ]; then
    echo -e "${RED}Failed to install packages${NC}"
    exit 1
fi

# Setup MongoDB
echo -e "${YELLOW}[3/8] Setting up MongoDB...${NC}"
mkdir -p ~/data/db

# Create MongoDB service script
cat > ~/start-mongodb.sh << 'EOF'
#!/bin/bash
echo "Starting MongoDB..."
mongod --dbpath ~/data/db --fork --logpath ~/data/mongod.log
echo "MongoDB started!"
EOF
chmod +x ~/start-mongodb.sh

# Create stop MongoDB script
cat > ~/stop-mongodb.sh << 'EOF'
#!/bin/bash
echo "Stopping MongoDB..."
pkill mongod
echo "MongoDB stopped!"
EOF
chmod +x ~/stop-mongodb.sh

# Get current directory
CURRENT_DIR=$(pwd)

# Setup Backend
echo -e "${YELLOW}[4/8] Setting up Backend...${NC}"
if [ -d "$CURRENT_DIR/backend" ]; then
    cd "$CURRENT_DIR/backend"
    
    echo "Installing backend dependencies..."
    npm install
    
    if [ $? -ne 0 ]; then
        echo -e "${RED}Failed to install backend dependencies${NC}"
        exit 1
    fi
    
    # Create .env if not exists
    if [ ! -f .env ]; then
        cat > .env << EOF
PORT=5000
MONGODB_URI=mongodb://127.0.0.1:27017/trivo
JWT_SECRET=trivo_secret_key_$(date +%s)
JWT_EXPIRE=30d
NODE_ENV=development
EOF
        echo -e "${GREEN}Created .env file${NC}"
    fi
    
    cd "$CURRENT_DIR"
else
    echo -e "${RED}Backend directory not found!${NC}"
    exit 1
fi

# Setup Frontend
echo -e "${YELLOW}[5/8] Setting up Frontend...${NC}"
if [ -d "$CURRENT_DIR/frontend" ]; then
    cd "$CURRENT_DIR/frontend"
    
    echo "Installing frontend dependencies..."
    npm install
    
    if [ $? -ne 0 ]; then
        echo -e "${RED}Failed to install frontend dependencies${NC}"
        exit 1
    fi
    
    cd "$CURRENT_DIR"
else
    echo -e "${RED}Frontend directory not found!${NC}"
    exit 1
fi

# Create start scripts
echo -e "${YELLOW}[6/8] Creating start scripts...${NC}"

# Backend start script
cat > "$CURRENT_DIR/start-backend.sh" << EOF
#!/bin/bash
cd "$CURRENT_DIR/backend"
echo "Starting Trivo Backend..."
npm start
EOF
chmod +x "$CURRENT_DIR/start-backend.sh"

# Frontend start script
cat > "$CURRENT_DIR/start-frontend.sh" << EOF
#!/bin/bash
cd "$CURRENT_DIR/frontend"
echo "Starting Trivo Frontend..."
npm start
EOF
chmod +x "$CURRENT_DIR/start-frontend.sh"

# All-in-one start script
cat > "$CURRENT_DIR/start-all.sh" << 'EOF'
#!/bin/bash
echo "=========================================="
echo "  Starting Trivo Dating App"
echo "=========================================="
echo ""

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Start MongoDB
echo "[1/3] Starting MongoDB..."
~/start-mongodb.sh
sleep 3

# Start Backend
echo "[2/3] Starting Backend..."
cd "$SCRIPT_DIR/backend"
npm start &
BACKEND_PID=$!
echo "Backend PID: $BACKEND_PID"
sleep 5

# Start Frontend
echo "[3/3] Starting Frontend..."
cd "$SCRIPT_DIR/frontend"
npm start &
FRONTEND_PID=$!
echo "Frontend PID: $FRONTEND_PID"

echo ""
echo "=========================================="
echo "  Trivo is running!"
echo "  Backend: http://localhost:5000"
echo "  Frontend: http://localhost:3000"
echo "=========================================="
echo ""
echo "Press Ctrl+C to stop all services"
echo ""

# Wait for interrupt
trap "kill $BACKEND_PID $FRONTEND_PID 2>/dev/null; ~/stop-mongodb.sh; exit" INT
wait
EOF
chmod +x "$CURRENT_DIR/start-all.sh"

# Create stop script
cat > "$CURRENT_DIR/stop-all.sh" << 'EOF'
#!/bin/bash
echo "Stopping Trivo..."
pkill -f "node.*backend"
pkill -f "node.*frontend"
~/stop-mongodb.sh
echo "Trivo stopped!"
EOF
chmod +x "$CURRENT_DIR/stop-all.sh"

# Create quick install dependencies script
cat > "$CURRENT_DIR/reinstall-deps.sh" << 'EOF'
#!/bin/bash
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "Reinstalling backend dependencies..."
cd "$SCRIPT_DIR/backend"
rm -rf node_modules package-lock.json
npm install

echo "Reinstalling frontend dependencies..."
cd "$SCRIPT_DIR/frontend"
rm -rf node_modules package-lock.json
npm install

echo "Done!"
EOF
chmod +x "$CURRENT_DIR/reinstall-deps.sh"

echo -e "${YELLOW}[7/8] Creating uploads directories...${NC}"
mkdir -p "$CURRENT_DIR/backend/uploads/photos"
mkdir -p "$CURRENT_DIR/backend/uploads/avatars"
mkdir -p "$CURRENT_DIR/backend/uploads/stories"

echo -e "${YELLOW}[8/8] Setup complete!${NC}"
echo ""
echo -e "${GREEN}==========================================${NC}"
echo -e "${GREEN}  Trivo Setup Complete!${NC}"
echo -e "${GREEN}==========================================${NC}"
echo ""
echo "To start Trivo:"
echo "  1. ./start-all.sh       - Start everything"
echo "  2. ./start-backend.sh   - Start backend only"
echo "  3. ./start-frontend.sh  - Start frontend only"
echo ""
echo "To stop Trivo:"
echo "  ./stop-all.sh"
echo ""
echo "Other commands:"
echo "  ~/start-mongodb.sh      - Start MongoDB"
echo "  ~/stop-mongodb.sh       - Stop MongoDB"
echo "  ./reinstall-deps.sh     - Reinstall dependencies"
echo ""
echo "Default URLs:"
echo "  Backend:  http://localhost:5000"
echo "  Frontend: http://localhost:3000"
echo ""
echo -e "${GREEN}Happy dating! 💝${NC}"
