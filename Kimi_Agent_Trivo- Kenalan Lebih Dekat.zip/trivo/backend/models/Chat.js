const mongoose = require('mongoose');

const MessageSchema = new mongoose.Schema({
  // Chat room ID
  chatRoom: {
    type: String,
    required: true,
    index: true
  },
  
  // Sender
  sender: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  
  // Receiver
  receiver: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  
  // Message content
  content: {
    type: String,
    required: function() {
      return this.messageType === 'text';
    }
  },
  
  // Message type
  messageType: {
    type: String,
    enum: ['text', 'image', 'emoji', 'location', 'voice'],
    default: 'text'
  },
  
  // Media URL (for images, voice)
  mediaUrl: String,
  
  // Emoji code
  emoji: String,
  
  // Status
  status: {
    type: String,
    enum: ['sent', 'delivered', 'read'],
    default: 'sent'
  },
  
  // Read by receiver
  readAt: Date,
  
  // Deleted by users (soft delete)
  deletedBy: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }],
  
  // Reply to message
  replyTo: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Message'
  },
  
  // Reactions
  reactions: [{
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    emoji: String
  }]
}, {
  timestamps: true
});

// Index for faster queries
MessageSchema.index({ chatRoom: 1, createdAt: -1 });
MessageSchema.index({ sender: 1, receiver: 1 });

const Message = mongoose.model('Message', MessageSchema);

// Chat Room Schema
const ChatRoomSchema = new mongoose.Schema({
  roomId: {
    type: String,
    required: true,
    unique: true
  },
  
  // Participants
  participants: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }],
  
  // Match reference
  match: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Match'
  },
  
  // Settings
  settings: {
    isMuted: {
      type: Map,
      of: Boolean,
      default: {}
    },
    isArchived: {
      type: Map,
      of: Boolean,
      default: {}
    }
  },
  
  // Last activity
  lastActivity: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true
});

const ChatRoom = mongoose.model('ChatRoom', ChatRoomSchema);

module.exports = { Message, ChatRoom };
