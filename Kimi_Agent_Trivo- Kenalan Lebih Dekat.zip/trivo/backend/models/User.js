const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const UserSchema = new mongoose.Schema({
  // Basic Info
  email: {
    type: String,
    required: [true, 'Please add an email'],
    unique: true,
    lowercase: true,
    trim: true
  },
  password: {
    type: String,
    required: [true, 'Please add a password'],
    minlength: 6,
    select: false
  },
  phone: {
    type: String,
    unique: true,
    sparse: true
  },
  
  // Profile Info
  name: {
    type: String,
    required: [true, 'Please add a name'],
    trim: true,
    maxlength: [50, 'Name cannot be more than 50 characters']
  },
  age: {
    type: Number,
    min: [18, 'Must be at least 18 years old'],
    max: [100, 'Age cannot be more than 100']
  },
  gender: {
    type: String,
    enum: ['male', 'female', 'other', 'prefer_not_to_say'],
    default: 'prefer_not_to_say'
  },
  bio: {
    type: String,
    maxlength: [500, 'Bio cannot be more than 500 characters']
  },
  city: {
    type: String,
    trim: true
  },
  
  // Photos
  photos: [{
    url: String,
    isMain: {
      type: Boolean,
      default: false
    },
    order: Number
  }],
  
  // Location (GPS)
  location: {
    type: {
      type: String,
      enum: ['Point'],
      default: 'Point'
    },
    coordinates: {
      type: [Number], // [longitude, latitude]
      default: [0, 0]
    }
  },
  
  // Preferences
  preferences: {
    lookingFor: {
      type: String,
      enum: ['male', 'female', 'both', 'all'],
      default: 'all'
    },
    ageRange: {
      min: { type: Number, default: 18 },
      max: { type: Number, default: 50 }
    },
    distance: {
      type: Number,
      default: 10 // km
    }
  },
  
  // Status
  isOnline: {
    type: Boolean,
    default: false
  },
  lastActive: {
    type: Date,
    default: Date.now
  },
  
  // Account Status
  isVerified: {
    type: Boolean,
    default: false
  },
  isActive: {
    type: Boolean,
    default: true
  },
  
  // Premium Features
  isPremium: {
    type: Boolean,
    default: false
  },
  premiumExpiry: Date,
  boosts: {
    count: { type: Number, default: 0 },
    active: { type: Boolean, default: false },
    expiresAt: Date
  },
  
  // Stats
  stats: {
    likesReceived: { type: Number, default: 0 },
    likesGiven: { type: Number, default: 0 },
    matches: { type: Number, default: 0 },
    profileViews: { type: Number, default: 0 }
  },
  
  // Social Links
  socialLinks: {
    instagram: String,
    twitter: String,
    facebook: String
  },
  
  // Interests/Tags
  interests: [String],
  
  // Blocked Users
  blockedUsers: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }],
  
  // Reported By
  reportedBy: [{
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    reason: String,
    date: {
      type: Date,
      default: Date.now
    }
  }]
}, {
  timestamps: true
});

// Index for geospatial queries
UserSchema.index({ location: '2dsphere' });

// Encrypt password using bcrypt
UserSchema.pre('save', async function(next) {
  if (!this.isModified('password')) {
    next();
  }
  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
});

// Match user entered password to hashed password in database
UserSchema.methods.matchPassword = async function(enteredPassword) {
  return await bcrypt.compare(enteredPassword, this.password);
};

// Get age from birthdate if age not set
UserSchema.virtual('displayAge').get(function() {
  return this.age || 'Not specified';
});

// Get main photo
UserSchema.virtual('mainPhoto').get(function() {
  const mainPhoto = this.photos.find(p => p.isMain);
  return mainPhoto ? mainPhoto.url : (this.photos.length > 0 ? this.photos[0].url : null);
});

module.exports = mongoose.model('User', UserSchema);
