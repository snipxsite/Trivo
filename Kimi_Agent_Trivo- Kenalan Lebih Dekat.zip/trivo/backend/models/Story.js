const mongoose = require('mongoose');

const StorySchema = new mongoose.Schema({
  // Story owner
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  
  // Media
  mediaUrl: {
    type: String,
    required: true
  },
  
  // Media type
  mediaType: {
    type: String,
    enum: ['image', 'video'],
    default: 'image'
  },
  
  // Caption/text
  caption: {
    type: String,
    maxlength: 200
  },
  
  // Background color (for text stories)
  backgroundColor: {
    type: String,
    default: '#FF6B6B'
  },
  
  // Views
  views: [{
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    viewedAt: {
      type: Date,
      default: Date.now
    }
  }],
  
  // Reactions
  reactions: [{
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    emoji: String,
    createdAt: {
      type: Date,
      default: Date.now
    }
  }],
  
  // Visibility
  visibility: {
    type: String,
    enum: ['public', 'matches', 'close_friends'],
    default: 'public'
  },
  
  // Hide from
  hiddenFrom: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }],
  
  // Expiry (24 hours)
  expiresAt: {
    type: Date,
    required: true
  },
  
  // Is active
  isActive: {
    type: Boolean,
    default: true
  }
}, {
  timestamps: true
});

// Index for expiry
StorySchema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 });
StorySchema.index({ user: 1, createdAt: -1 });

// Static method to get active stories
StorySchema.statics.getActiveStories = async function(userId) {
  const now = new Date();
  return await this.find({
    user: { $ne: userId },
    expiresAt: { $gt: now },
    isActive: true,
    hiddenFrom: { $ne: userId }
  })
  .populate('user', 'name photos')
  .sort({ createdAt: -1 });
};

// Static method to get user's stories
StorySchema.statics.getUserStories = async function(userId) {
  const now = new Date();
  return await this.find({
    user: userId,
    expiresAt: { $gt: now },
    isActive: true
  }).sort({ createdAt: -1 });
};

module.exports = mongoose.model('Story', StorySchema);
