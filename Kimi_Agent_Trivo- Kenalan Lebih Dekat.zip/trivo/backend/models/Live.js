const mongoose = require('mongoose');

const LiveStreamSchema = new mongoose.Schema({
  // Streamer
  streamer: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  
  // Stream title
  title: {
    type: String,
    required: true,
    maxlength: 100
  },
  
  // Stream URL/Key
  streamKey: {
    type: String,
    unique: true
  },
  
  // Thumbnail
  thumbnail: String,
  
  // Category
  category: {
    type: String,
    default: 'Just Chatting'
  },
  
  // Viewers
  viewers: [{
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    joinedAt: {
      type: Date,
      default: Date.now
    }
  }],
  
  // Viewer count (cached)
  viewerCount: {
    type: Number,
    default: 0
  },
  
  // Total unique viewers
  totalViewers: {
    type: Number,
    default: 0
  },
  
  // Gifts received
  gifts: [{
    sender: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    giftType: {
      type: String,
      enum: ['rose', 'heart', 'diamond', 'crown', 'star']
    },
    amount: Number,
    message: String,
    sentAt: {
      type: Date,
      default: Date.now
    }
  }],
  
  // Total gifts value
  totalGifts: {
    type: Number,
    default: 0
  },
  
  // Comments
  comments: [{
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    text: String,
    sentAt: {
      type: Date,
      default: Date.now
    }
  }],
  
  // Status
  status: {
    type: String,
    enum: ['live', 'ended', 'banned'],
    default: 'live'
  },
  
  // Started at
  startedAt: {
    type: Date,
    default: Date.now
  },
  
  // Ended at
  endedAt: Date,
  
  // Duration in seconds
  duration: Number,
  
  // Is featured
  isFeatured: {
    type: Boolean,
    default: false
  },
  
  // Region
  region: String
}, {
  timestamps: true
});

// Index for active streams
LiveStreamSchema.index({ status: 1, startedAt: -1 });
LiveStreamSchema.index({ streamer: 1 });

// Static method to get active streams
LiveStreamSchema.statics.getActiveStreams = async function() {
  return await this.find({ status: 'live' })
    .populate('streamer', 'name photos')
    .sort({ viewerCount: -1, isFeatured: -1 });
};

// Static method to get trending streamers
LiveStreamSchema.statics.getTrendingStreamers = async function() {
  const oneWeekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
  
  return await this.aggregate([
    {
      $match: {
        startedAt: { $gte: oneWeekAgo }
      }
    },
    {
      $group: {
        _id: '$streamer',
        totalViewers: { $sum: '$totalViewers' },
        totalGifts: { $sum: '$totalGifts' },
        streamCount: { $sum: 1 }
      }
    },
    {
      $sort: { totalViewers: -1, totalGifts: -1 }
    },
    {
      $limit: 10
    }
  ]);
};

module.exports = mongoose.model('LiveStream', LiveStreamSchema);
