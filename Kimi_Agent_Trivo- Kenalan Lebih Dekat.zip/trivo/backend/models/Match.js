const mongoose = require('mongoose');

const MatchSchema = new mongoose.Schema({
  // Users in the match
  users: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  }],
  
  // User who initiated the like
  initiator: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  
  // Match status
  status: {
    type: String,
    enum: ['pending', 'matched', 'unmatched', 'blocked'],
    default: 'pending'
  },
  
  // When both users liked each other
  matchedAt: {
    type: Date,
    default: null
  },
  
  // Who unmatched
  unmatchedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    default: null
  },
  
  // Chat room ID
  chatRoom: {
    type: String,
    unique: true,
    sparse: true
  },
  
  // Last message preview
  lastMessage: {
    text: String,
    sender: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    sentAt: Date,
    isRead: {
      type: Boolean,
      default: false
    }
  },
  
  // Unread count for each user
  unreadCount: {
    type: Map,
    of: Number,
    default: {}
  }
}, {
  timestamps: true
});

// Index for faster queries
MatchSchema.index({ users: 1 });
MatchSchema.index({ status: 1 });
MatchSchema.index({ matchedAt: -1 });

// Static method to check if match exists between two users
MatchSchema.statics.findMatch = async function(userId1, userId2) {
  return await this.findOne({
    users: { $all: [userId1, userId2] }
  });
};

// Static method to get all matches for a user
MatchSchema.statics.getUserMatches = async function(userId) {
  return await this.find({
    users: userId,
    status: 'matched'
  })
  .populate('users', 'name photos age isOnline lastActive')
  .sort({ 'lastMessage.sentAt': -1, matchedAt: -1 });
};

module.exports = mongoose.model('Match', MatchSchema);
