const User = require('../models/User');
const { Message } = require('../models/Chat');

module.exports = (io) => {
  // Store connected users
  const connectedUsers = new Map();

  io.on('connection', (socket) => {
    console.log('New client connected:', socket.id);

    // User authentication
    socket.on('authenticate', async (data) => {
      try {
        const { userId } = data;
        
        if (!userId) {
          socket.emit('auth_error', { message: 'User ID required' });
          return;
        }

        // Store user connection
        connectedUsers.set(userId, socket.id);
        socket.userId = userId;

        // Join user's personal room
        socket.join(userId);

        // Update user online status
        await User.findByIdAndUpdate(userId, {
          isOnline: true,
          lastActive: new Date()
        });

        // Notify friends/matches that user is online
        socket.broadcast.emit('user_online', { userId });

        socket.emit('authenticated', { success: true });
        console.log(`User ${userId} authenticated`);
      } catch (error) {
        console.error('Socket authentication error:', error);
        socket.emit('auth_error', { message: 'Authentication failed' });
      }
    });

    // Join chat room
    socket.on('join_room', (data) => {
      const { roomId } = data;
      socket.join(roomId);
      console.log(`Socket ${socket.id} joined room ${roomId}`);
    });

    // Leave chat room
    socket.on('leave_room', (data) => {
      const { roomId } = data;
      socket.leave(roomId);
      console.log(`Socket ${socket.id} left room ${roomId}`);
    });

    // Typing indicator
    socket.on('typing', (data) => {
      const { roomId, isTyping } = data;
      socket.to(roomId).emit('typing', {
        userId: socket.userId,
        isTyping
      });
    });

    // Message read receipt
    socket.on('message_read', async (data) => {
      try {
        const { messageId } = data;
        
        const message = await Message.findById(messageId);
        if (message) {
          message.status = 'read';
          message.readAt = new Date();
          await message.save();

          // Notify sender
          io.to(message.sender.toString()).emit('message_read', {
            messageId,
            readAt: message.readAt
          });
        }
      } catch (error) {
        console.error('Message read error:', error);
      }
    });

    // Join live stream room
    socket.on('join_stream', (data) => {
      const { streamId } = data;
      socket.join(`stream_${streamId}`);
      console.log(`Socket ${socket.id} joined stream ${streamId}`);
    });

    // Leave live stream room
    socket.on('leave_stream', (data) => {
      const { streamId } = data;
      socket.leave(`stream_${streamId}`);
      console.log(`Socket ${socket.id} left stream ${streamId}`);
    });

    // Live stream heart/like
    socket.on('stream_like', (data) => {
      const { streamId } = data;
      socket.to(`stream_${streamId}`).emit('stream_like', {
        streamId,
        userId: socket.userId
      });
    });

    // Disconnect
    socket.on('disconnect', async () => {
      console.log('Client disconnected:', socket.id);

      if (socket.userId) {
        // Remove from connected users
        connectedUsers.delete(socket.userId);

        // Update user offline status
        await User.findByIdAndUpdate(socket.userId, {
          isOnline: false,
          lastActive: new Date()
        });

        // Notify others that user is offline
        socket.broadcast.emit('user_offline', { userId: socket.userId });
      }
    });
  });

  // Helper function to get socket ID by user ID
  const getUserSocket = (userId) => {
    return connectedUsers.get(userId);
  };

  // Helper function to check if user is online
  const isUserOnline = (userId) => {
    return connectedUsers.has(userId);
  };

  // Export helpers
  global.getUserSocket = getUserSocket;
  global.isUserOnline = isUserOnline;
};
