const express = require('express');
const router = express.Router();
const User = require('../models/User');
const Match = require('../models/Match');
const { protect, updateLastActive } = require('../middleware/auth');
const { uploadSingle, handleUploadError, getFileUrl } = require('../middleware/upload');

// @route   GET /api/users
// @desc    Get all users (with filters)
// @access  Private
router.get('/', protect, async (req, res) => {
  try {
    const { 
      gender, 
      minAge, 
      maxAge, 
      city, 
      interests,
      page = 1, 
      limit = 20 
    } = req.query;

    const query = { 
      _id: { $ne: req.user.id },
      isActive: true
    };

    // Filter by gender
    if (gender) {
      query.gender = gender;
    }

    // Filter by age range
    if (minAge || maxAge) {
      query.age = {};
      if (minAge) query.age.$gte = parseInt(minAge);
      if (maxAge) query.age.$lte = parseInt(maxAge);
    }

    // Filter by city
    if (city) {
      query.city = { $regex: city, $options: 'i' };
    }

    // Filter by interests
    if (interests) {
      const interestArray = interests.split(',');
      query.interests = { $in: interestArray };
    }

    const users = await User.find(query)
      .select('-password -email -phone')
      .limit(limit * 1)
      .skip((page - 1) * limit)
      .sort({ lastActive: -1 });

    const count = await User.countDocuments(query);

    res.json({
      success: true,
      count: users.length,
      total: count,
      totalPages: Math.ceil(count / limit),
      currentPage: page,
      users
    });
  } catch (error) {
    console.error('Get users error:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Server error'
    });
  }
});

// @route   GET /api/users/nearby
// @desc    Get nearby users based on GPS location
// @access  Private
router.get('/nearby', protect, async (req, res) => {
  try {
    const { radius = 10, page = 1, limit = 20 } = req.query; // radius in km

    if (!req.user.location || req.user.location.coordinates[0] === 0) {
      return res.status(400).json({
        success: false,
        message: 'Please update your location first'
      });
    }

    const [longitude, latitude] = req.user.location.coordinates;

    // Find users within radius
    const users = await User.find({
      _id: { $ne: req.user.id },
      isActive: true,
      location: {
        $near: {
          $geometry: {
            type: 'Point',
            coordinates: [longitude, latitude]
          },
          $maxDistance: radius * 1000 // Convert km to meters
        }
      }
    })
    .select('-password -email -phone')
    .limit(limit * 1)
    .skip((page - 1) * limit);

    // Calculate distance for each user
    const usersWithDistance = users.map(user => {
      const userObj = user.toObject();
      
      // Calculate distance using Haversine formula
      const R = 6371; // Earth's radius in km
      const dLat = (user.location.coordinates[1] - latitude) * Math.PI / 180;
      const dLon = (user.location.coordinates[0] - longitude) * Math.PI / 180;
      const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                Math.cos(latitude * Math.PI / 180) * Math.cos(user.location.coordinates[1] * Math.PI / 180) *
                Math.sin(dLon/2) * Math.sin(dLon/2);
      const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
      const distance = R * c;
      
      userObj.distance = Math.round(distance * 10) / 10; // Round to 1 decimal
      return userObj;
    });

    res.json({
      success: true,
      count: users.length,
      radius: parseInt(radius),
      users: usersWithDistance
    });
  } catch (error) {
    console.error('Get nearby users error:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Server error'
    });
  }
});

// @route   GET /api/users/explore
// @desc    Get users for explore/discovery (swipe)
// @access  Private
router.get('/explore', protect, async (req, res) => {
  try {
    const { radius = 10 } = req.query;
    
    // Get user's preferences
    const { preferences } = req.user;
    const lookingFor = preferences.lookingFor;
    const ageRange = preferences.ageRange;
    
    // Get already swiped users
    const existingMatches = await Match.find({
      users: req.user.id
    }).select('users');
    
    const swipedUserIds = existingMatches.flatMap(m => 
      m.users.filter(u => u.toString() !== req.user.id)
    );
    
    // Build query
    const query = {
      _id: { 
        $ne: req.user.id,
        $nin: swipedUserIds
      },
      isActive: true,
      age: {
        $gte: ageRange.min,
        $lte: ageRange.max
      }
    };
    
    // Filter by gender preference
    if (lookingFor !== 'all') {
      if (lookingFor === 'both') {
        query.gender = { $in: ['male', 'female'] };
      } else {
        query.gender = lookingFor;
      }
    }
    
    // Add location filter if user has location
    if (req.user.location && req.user.location.coordinates[0] !== 0) {
      const [longitude, latitude] = req.user.location.coordinates;
      query.location = {
        $near: {
          $geometry: {
            type: 'Point',
            coordinates: [longitude, latitude]
          },
          $maxDistance: radius * 1000
        }
      };
    }
    
    const users = await User.find(query)
      .select('-password -email -phone -blockedUsers -reportedBy')
      .limit(20)
      .sort({ isOnline: -1, lastActive: -1 });
    
    // Calculate distance
    const usersWithDistance = users.map(user => {
      const userObj = user.toObject();
      
      if (req.user.location && user.location) {
        const [longitude, latitude] = req.user.location.coordinates;
        const R = 6371;
        const dLat = (user.location.coordinates[1] - latitude) * Math.PI / 180;
        const dLon = (user.location.coordinates[0] - longitude) * Math.PI / 180;
        const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                  Math.cos(latitude * Math.PI / 180) * Math.cos(user.location.coordinates[1] * Math.PI / 180) *
                  Math.sin(dLon/2) * Math.sin(dLon/2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        const distance = R * c;
        userObj.distance = Math.round(distance * 10) / 10;
      }
      
      return userObj;
    });
    
    res.json({
      success: true,
      count: users.length,
      users: usersWithDistance
    });
  } catch (error) {
    console.error('Get explore users error:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Server error'
    });
  }
});

// @route   GET /api/users/:id
// @desc    Get single user profile
// @access  Private
router.get('/:id', protect, async (req, res) => {
  try {
    const user = await User.findById(req.params.id)
      .select('-password -email -phone -blockedUsers -reportedBy');

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    // Increment profile views
    user.stats.profileViews += 1;
    await user.save();

    res.json({
      success: true,
      user
    });
  } catch (error) {
    console.error('Get user error:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Server error'
    });
  }
});

// @route   PUT /api/users/profile
// @desc    Update user profile
// @access  Private
router.put('/profile', protect, async (req, res) => {
  try {
    const { name, age, bio, city, gender, interests, preferences } = req.body;

    const updateFields = {};
    if (name) updateFields.name = name;
    if (age) updateFields.age = age;
    if (bio !== undefined) updateFields.bio = bio;
    if (city) updateFields.city = city;
    if (gender) updateFields.gender = gender;
    if (interests) updateFields.interests = interests;
    if (preferences) updateFields.preferences = preferences;

    const user = await User.findByIdAndUpdate(
      req.user.id,
      updateFields,
      { new: true, runValidators: true }
    ).select('-password');

    res.json({
      success: true,
      user
    });
  } catch (error) {
    console.error('Update profile error:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Server error'
    });
  }
});

// @route   POST /api/users/avatar
// @desc    Upload avatar/main photo
// @access  Private
router.post('/avatar', protect, uploadSingle('avatar'), handleUploadError, async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: 'Please upload an image'
      });
    }

    const user = await User.findById(req.user.id);
    
    // Set all existing photos as not main
    user.photos.forEach(photo => {
      photo.isMain = false;
    });

    // Add new photo as main
    user.photos.push({
      url: getFileUrl(req.file.filename, 'avatars'),
      isMain: true,
      order: 0
    });

    await user.save();

    res.json({
      success: true,
      message: 'Avatar uploaded successfully',
      photo: user.photos.find(p => p.isMain)
    });
  } catch (error) {
    console.error('Upload avatar error:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Server error'
    });
  }
});

// @route   POST /api/users/photos
// @desc    Upload multiple photos
// @access  Private
router.post('/photos', protect, uploadSingle('photo'), handleUploadError, async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: 'Please upload an image'
      });
    }

    const user = await User.findById(req.user.id);
    
    user.photos.push({
      url: getFileUrl(req.file.filename, 'photos'),
      isMain: user.photos.length === 0,
      order: user.photos.length
    });

    await user.save();

    res.json({
      success: true,
      message: 'Photo uploaded successfully',
      photos: user.photos
    });
  } catch (error) {
    console.error('Upload photo error:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Server error'
    });
  }
});

// @route   DELETE /api/users/photos/:photoId
// @desc    Delete a photo
// @access  Private
router.delete('/photos/:photoId', protect, async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    
    const photoIndex = user.photos.findIndex(
      p => p._id.toString() === req.params.photoId
    );
    
    if (photoIndex === -1) {
      return res.status(404).json({
        success: false,
        message: 'Photo not found'
      });
    }

    user.photos.splice(photoIndex, 1);
    
    // If deleted photo was main, set first photo as main
    if (user.photos.length > 0 && !user.photos.some(p => p.isMain)) {
      user.photos[0].isMain = true;
    }

    await user.save();

    res.json({
      success: true,
      message: 'Photo deleted successfully',
      photos: user.photos
    });
  } catch (error) {
    console.error('Delete photo error:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Server error'
    });
  }
});

// @route   PUT /api/users/photos/:photoId/main
// @desc    Set photo as main
// @access  Private
router.put('/photos/:photoId/main', protect, async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    
    const photo = user.photos.id(req.params.photoId);
    
    if (!photo) {
      return res.status(404).json({
        success: false,
        message: 'Photo not found'
      });
    }

    // Set all photos as not main
    user.photos.forEach(p => {
      p.isMain = false;
    });

    // Set selected photo as main
    photo.isMain = true;

    await user.save();

    res.json({
      success: true,
      message: 'Main photo updated',
      photos: user.photos
    });
  } catch (error) {
    console.error('Set main photo error:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Server error'
    });
  }
});

// @route   POST /api/users/:id/block
// @desc    Block a user
// @access  Private
router.post('/:id/block', protect, async (req, res) => {
  try {
    if (req.params.id === req.user.id) {
      return res.status(400).json({
        success: false,
        message: 'Cannot block yourself'
      });
    }

    const user = await User.findById(req.user.id);
    
    if (user.blockedUsers.includes(req.params.id)) {
      return res.status(400).json({
        success: false,
        message: 'User already blocked'
      });
    }

    user.blockedUsers.push(req.params.id);
    await user.save();

    // Also update any existing match to blocked
    await Match.findOneAndUpdate(
      { users: { $all: [req.user.id, req.params.id] } },
      { status: 'blocked' }
    );

    res.json({
      success: true,
      message: 'User blocked successfully'
    });
  } catch (error) {
    console.error('Block user error:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Server error'
    });
  }
});

// @route   POST /api/users/:id/report
// @desc    Report a user
// @access  Private
router.post('/:id/report', protect, async (req, res) => {
  try {
    const { reason } = req.body;
    
    if (req.params.id === req.user.id) {
      return res.status(400).json({
        success: false,
        message: 'Cannot report yourself'
      });
    }

    const reportedUser = await User.findById(req.params.id);
    
    if (!reportedUser) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    // Check if already reported by this user
    const alreadyReported = reportedUser.reportedBy.some(
      r => r.user.toString() === req.user.id
    );

    if (alreadyReported) {
      return res.status(400).json({
        success: false,
        message: 'You have already reported this user'
      });
    }

    reportedUser.reportedBy.push({
      user: req.user.id,
      reason: reason || 'Inappropriate behavior'
    });

    await reportedUser.save();

    res.json({
      success: true,
      message: 'User reported successfully'
    });
  } catch (error) {
    console.error('Report user error:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Server error'
    });
  }
});

module.exports = router;
