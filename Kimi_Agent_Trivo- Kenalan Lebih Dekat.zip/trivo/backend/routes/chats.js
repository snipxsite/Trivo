const express = require('express');
const router = express.Router();
const { Message, ChatRoom } = require('../models/Chat');
const Match = require('../models/Match');
const { protect } = require('../middleware/auth');

// @route   GET /api/chats/rooms
// @desc    Get all chat rooms for current user
// @access  Private
router.get('/rooms', protect, async (req, res) => {
  try {
    const chatRooms = await ChatRoom.find({
      participants: req.user.id
    })
    .populate('participants', 'name photos isOnline lastActive')
    .sort({ lastActivity: -1 });

    // Get unread count for each room
    const roomsWithUnread = await Promise.all(
      chatRooms.map(async (room) => {
        const unreadCount = await Message.countDocuments({
          chatRoom: room.roomId,
          receiver: req.user.id,
          status: { $ne: 'read' }
        });

        const otherUser = room.participants.find(
          p => p._id.toString() !== req.user.id
        );

        // Get last message
        const lastMessage = await Message.findOne({
          chatRoom: room.roomId
        })
        .sort({ createdAt: -1 })
        .populate('sender', 'name');

        return {
          _id: room._id,
          roomId: room.roomId,
          user: otherUser,
          unreadCount,
          lastMessage,
          lastActivity: room.lastActivity
        };
      })
    );

    res.json({
      success: true,
      count: roomsWithUnread.length,
      rooms: roomsWithUnread
    });
  } catch (error) {
    console.error('Get chat rooms error:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Server error'
    });
  }
});

// @route   GET /api/chats/:roomId/messages
// @desc    Get messages for a chat room
// @access  Private
router.get('/:roomId/messages', protect, async (req, res) => {
  try {
    const { page = 1, limit = 50 } = req.query;

    // Check if user is part of this chat room
    const chatRoom = await ChatRoom.findOne({
      roomId: req.params.roomId,
      participants: req.user.id
    });

    if (!chatRoom) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to access this chat'
      });
    }

    const messages = await Message.find({
      chatRoom: req.params.roomId,
      deletedBy: { $ne: req.user.id }
    })
    .populate('sender', 'name photos')
    .populate('receiver', 'name photos')
    .sort({ createdAt: -1 })
    .limit(limit * 1)
    .skip((page - 1) * limit);

    const total = await Message.countDocuments({
      chatRoom: req.params.roomId,
      deletedBy: { $ne: req.user.id }
    });

    // Mark messages as read
    await Message.updateMany(
      {
        chatRoom: req.params.roomId,
        receiver: req.user.id,
        status: { $ne: 'read' }
      },
      {
        status: 'read',
        readAt: new Date()
      }
    );

    // Update match unread count
    await Match.findOneAndUpdate(
      { chatRoom: req.params.roomId },
      {
        $set: {
          [`unreadCount.${req.user.id}`]: 0
        }
      }
    );

    res.json({
      success: true,
      count: messages.length,
      total,
      totalPages: Math.ceil(total / limit),
      currentPage: page,
      messages: messages.reverse() // Return in chronological order
    });
  } catch (error) {
    console.error('Get messages error:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Server error'
    });
  }
});

// @route   POST /api/chats/:roomId/messages
// @desc    Send a message
// @access  Private
router.post('/:roomId/messages', protect, async (req, res) => {
  try {
    const { content, messageType = 'text', mediaUrl, emoji } = req.body;

    // Check if user is part of this chat room
    const chatRoom = await ChatRoom.findOne({
      roomId: req.params.roomId,
      participants: req.user.id
    });

    if (!chatRoom) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to send message in this chat'
      });
    }

    // Get receiver (other participant)
    const receiver = chatRoom.participants.find(
      p => p.toString() !== req.user.id
    );

    // Create message
    const message = await Message.create({
      chatRoom: req.params.roomId,
      sender: req.user.id,
      receiver,
      content,
      messageType,
      mediaUrl,
      emoji,
      status: 'sent'
    });

    // Populate sender info
    await message.populate('sender', 'name photos');
    await message.populate('receiver', 'name photos');

    // Update chat room last activity
    chatRoom.lastActivity = Date.now();
    await chatRoom.save();

    // Update match last message
    await Match.findOneAndUpdate(
      { chatRoom: req.params.roomId },
      {
        lastMessage: {
          text: content || (messageType === 'emoji' ? emoji : 'Media'),
          sender: req.user.id,
          sentAt: new Date(),
          isRead: false
        },
        $inc: {
          [`unreadCount.${receiver.toString()}`]: 1
        }
      }
    );

    // Emit real-time message
    const io = req.app.get('io');
    io.to(receiver.toString()).emit('new_message', {
      roomId: req.params.roomId,
      message
    });

    res.status(201).json({
      success: true,
      message
    });
  } catch (error) {
    console.error('Send message error:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Server error'
    });
  }
});

// @route   PUT /api/chats/messages/:messageId/read
// @desc    Mark message as read
// @access  Private
router.put('/messages/:messageId/read', protect, async (req, res) => {
  try {
    const message = await Message.findById(req.params.messageId);

    if (!message) {
      return res.status(404).json({
        success: false,
        message: 'Message not found'
      });
    }

    // Check if user is the receiver
    if (message.receiver.toString() !== req.user.id) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized'
      });
    }

    message.status = 'read';
    message.readAt = new Date();
    await message.save();

    // Notify sender that message was read
    const io = req.app.get('io');
    io.to(message.sender.toString()).emit('message_read', {
      messageId: message._id,
      readAt: message.readAt
    });

    res.json({
      success: true,
      message: 'Message marked as read'
    });
  } catch (error) {
    console.error('Mark read error:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Server error'
    });
  }
});

// @route   DELETE /api/chats/messages/:messageId
// @desc    Delete a message (soft delete)
// @access  Private
router.delete('/messages/:messageId', protect, async (req, res) => {
  try {
    const message = await Message.findById(req.params.messageId);

    if (!message) {
      return res.status(404).json({
        success: false,
        message: 'Message not found'
      });
    }

    // Check if user is the sender
    if (message.sender.toString() !== req.user.id) {
      return res.status(403).json({
        success: false,
        message: 'Can only delete your own messages'
      });
    }

    // Soft delete
    message.deletedBy.push(req.user.id);
    await message.save();

    // Notify other user
    const io = req.app.get('io');
    io.to(message.receiver.toString()).emit('message_deleted', {
      messageId: message._id
    });

    res.json({
      success: true,
      message: 'Message deleted'
    });
  } catch (error) {
    console.error('Delete message error:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Server error'
    });
  }
});

// @route   POST /api/chats/:roomId/typing
// @desc    Send typing indicator
// @access  Private
router.post('/:roomId/typing', protect, async (req, res) => {
  try {
    const { isTyping } = req.body;

    const chatRoom = await ChatRoom.findOne({
      roomId: req.params.roomId,
      participants: req.user.id
    });

    if (!chatRoom) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized'
      });
    }

    const receiver = chatRoom.participants.find(
      p => p.toString() !== req.user.id
    );

    // Emit typing event
    const io = req.app.get('io');
    io.to(receiver.toString()).emit('typing', {
      roomId: req.params.roomId,
      userId: req.user.id,
      isTyping
    });

    res.json({
      success: true
    });
  } catch (error) {
    console.error('Typing indicator error:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Server error'
    });
  }
});

// @route   GET /api/chats/unread-count
// @desc    Get total unread message count
// @access  Private
router.get('/unread-count', protect, async (req, res) => {
  try {
    const unreadCount = await Message.countDocuments({
      receiver: req.user.id,
      status: { $ne: 'read' }
    });

    res.json({
      success: true,
      unreadCount
    });
  } catch (error) {
    console.error('Get unread count error:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Server error'
    });
  }
});

module.exports = router;
