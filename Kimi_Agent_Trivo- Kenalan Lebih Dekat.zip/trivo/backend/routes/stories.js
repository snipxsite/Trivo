const express = require('express');
const router = express.Router();
const Story = require('../models/Story');
const { protect } = require('../middleware/auth');
const { uploadSingle, handleUploadError, getFileUrl } = require('../middleware/upload');

// @route   GET /api/stories
// @desc    Get all active stories (from other users)
// @access  Private
router.get('/', protect, async (req, res) => {
  try {
    const stories = await Story.getActiveStories(req.user.id);

    // Group stories by user
    const storiesByUser = stories.reduce((acc, story) => {
      const userId = story.user._id.toString();
      
      if (!acc[userId]) {
        acc[userId] = {
          user: story.user,
          stories: []
        };
      }
      
      acc[userId].stories.push({
        _id: story._id,
        mediaUrl: story.mediaUrl,
        mediaType: story.mediaType,
        caption: story.caption,
        backgroundColor: story.backgroundColor,
        createdAt: story.createdAt,
        expiresAt: story.expiresAt,
        viewCount: story.views.length,
        hasViewed: story.views.some(v => v.user.toString() === req.user.id)
      });
      
      return acc;
    }, {});

    res.json({
      success: true,
      count: stories.length,
      stories: Object.values(storiesByUser)
    });
  } catch (error) {
    console.error('Get stories error:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Server error'
    });
  }
});

// @route   GET /api/stories/my
// @desc    Get current user's stories
// @access  Private
router.get('/my', protect, async (req, res) => {
  try {
    const stories = await Story.getUserStories(req.user.id);

    res.json({
      success: true,
      count: stories.length,
      stories: stories.map(story => ({
        _id: story._id,
        mediaUrl: story.mediaUrl,
        mediaType: story.mediaType,
        caption: story.caption,
        backgroundColor: story.backgroundColor,
        createdAt: story.createdAt,
        expiresAt: story.expiresAt,
        viewCount: story.views.length,
        views: story.views
      }))
    });
  } catch (error) {
    console.error('Get my stories error:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Server error'
    });
  }
});

// @route   POST /api/stories
// @desc    Create a new story
// @access  Private
router.post('/', protect, uploadSingle('media'), handleUploadError, async (req, res) => {
  try {
    const { caption, backgroundColor, mediaType = 'image' } = req.body;

    let mediaUrl;
    if (req.file) {
      mediaUrl = getFileUrl(req.file.filename, 'stories');
    } else if (req.body.mediaUrl) {
      mediaUrl = req.body.mediaUrl;
    } else {
      return res.status(400).json({
        success: false,
        message: 'Please provide media'
      });
    }

    // Create story with 24h expiry
    const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000);

    const story = await Story.create({
      user: req.user.id,
      mediaUrl,
      mediaType,
      caption,
      backgroundColor,
      expiresAt
    });

    res.status(201).json({
      success: true,
      story
    });
  } catch (error) {
    console.error('Create story error:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Server error'
    });
  }
});

// @route   POST /api/stories/text
// @desc    Create a text story
// @access  Private
router.post('/text', protect, async (req, res) => {
  try {
    const { caption, backgroundColor = '#FF6B6B' } = req.body;

    if (!caption) {
      return res.status(400).json({
        success: false,
        message: 'Please provide caption text'
      });
    }

    const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000);

    const story = await Story.create({
      user: req.user.id,
      mediaUrl: null,
      mediaType: 'image',
      caption,
      backgroundColor,
      expiresAt
    });

    res.status(201).json({
      success: true,
      story
    });
  } catch (error) {
    console.error('Create text story error:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Server error'
    });
  }
});

// @route   POST /api/stories/:id/view
// @desc    View a story
// @access  Private
router.post('/:id/view', protect, async (req, res) => {
  try {
    const story = await Story.findById(req.params.id);

    if (!story) {
      return res.status(404).json({
        success: false,
        message: 'Story not found'
      });
    }

    // Check if already viewed
    const alreadyViewed = story.views.some(
      v => v.user.toString() === req.user.id
    );

    if (!alreadyViewed) {
      story.views.push({
        user: req.user.id,
        viewedAt: new Date()
      });
      await story.save();
    }

    res.json({
      success: true,
      message: 'Story viewed'
    });
  } catch (error) {
    console.error('View story error:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Server error'
    });
  }
});

// @route   POST /api/stories/:id/react
// @desc    React to a story
// @access  Private
router.post('/:id/react', protect, async (req, res) => {
  try {
    const { emoji } = req.body;

    if (!emoji) {
      return res.status(400).json({
        success: false,
        message: 'Please provide emoji'
      });
    }

    const story = await Story.findById(req.params.id);

    if (!story) {
      return res.status(404).json({
        success: false,
        message: 'Story not found'
      });
    }

    // Remove existing reaction from this user
    story.reactions = story.reactions.filter(
      r => r.user.toString() !== req.user.id
    );

    // Add new reaction
    story.reactions.push({
      user: req.user.id,
      emoji
    });

    await story.save();

    // Notify story owner
    const io = req.app.get('io');
    io.to(story.user.toString()).emit('story_reaction', {
      storyId: story._id,
      from: {
        _id: req.user.id,
        name: req.user.name
      },
      emoji
    });

    res.json({
      success: true,
      message: 'Reaction added'
    });
  } catch (error) {
    console.error('React to story error:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Server error'
    });
  }
});

// @route   DELETE /api/stories/:id
// @desc    Delete a story
// @access  Private
router.delete('/:id', protect, async (req, res) => {
  try {
    const story = await Story.findById(req.params.id);

    if (!story) {
      return res.status(404).json({
        success: false,
        message: 'Story not found'
      });
    }

    // Check if user owns the story
    if (story.user.toString() !== req.user.id) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized'
      });
    }

    story.isActive = false;
    await story.save();

    res.json({
      success: true,
      message: 'Story deleted'
    });
  } catch (error) {
    console.error('Delete story error:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Server error'
    });
  }
});

// @route   GET /api/stories/explore
// @desc    Get trending/explore stories
// @access  Private
router.get('/explore', protect, async (req, res) => {
  try {
    const now = new Date();
    
    // Get stories with most views in last 24 hours
    const trendingStories = await Story.find({
      expiresAt: { $gt: now },
      isActive: true,
      user: { $ne: req.user.id }
    })
    .populate('user', 'name photos')
    .sort({ 'views.length': -1 })
    .limit(20);

    res.json({
      success: true,
      count: trendingStories.length,
      stories: trendingStories
    });
  } catch (error) {
    console.error('Get explore stories error:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Server error'
    });
  }
});

module.exports = router;
