const express = require('express');
const router = express.Router();
const LiveStream = require('../models/Live');
const User = require('../models/User');
const { protect } = require('../middleware/auth');
const { v4: uuidv4 } = require('uuid');

// @route   GET /api/live
// @desc    Get all active live streams
// @access  Private
router.get('/', protect, async (req, res) => {
  try {
    const { category, page = 1, limit = 20 } = req.query;

    const query = { status: 'live' };
    if (category) {
      query.category = category;
    }

    const liveStreams = await LiveStream.find(query)
      .populate('streamer', 'name photos age city')
      .sort({ viewerCount: -1, isFeatured: -1, startedAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const total = await LiveStream.countDocuments(query);

    res.json({
      success: true,
      count: liveStreams.length,
      total,
      totalPages: Math.ceil(total / limit),
      currentPage: page,
      streams: liveStreams
    });
  } catch (error) {
    console.error('Get live streams error:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Server error'
    });
  }
});

// @route   POST /api/live/start
// @desc    Start a new live stream
// @access  Private
router.post('/start', protect, async (req, res) => {
  try {
    const { title, category, thumbnail } = req.body;

    if (!title) {
      return res.status(400).json({
        success: false,
        message: 'Please provide a title'
      });
    }

    // Check if user already has an active stream
    const existingStream = await LiveStream.findOne({
      streamer: req.user.id,
      status: 'live'
    });

    if (existingStream) {
      return res.status(400).json({
        success: false,
        message: 'You already have an active stream'
      });
    }

    // Generate stream key
    const streamKey = uuidv4();

    const liveStream = await LiveStream.create({
      streamer: req.user.id,
      title,
      category: category || 'Just Chatting',
      thumbnail,
      streamKey,
      status: 'live',
      startedAt: new Date()
    });

    // Notify followers (if implemented)
    const io = req.app.get('io');
    io.emit('new_live_stream', {
      streamId: liveStream._id,
      streamer: {
        _id: req.user.id,
        name: req.user.name,
        photos: req.user.photos
      },
      title,
      category
    });

    res.status(201).json({
      success: true,
      stream: liveStream
    });
  } catch (error) {
    console.error('Start live stream error:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Server error'
    });
  }
});

// @route   POST /api/live/:id/end
// @desc    End a live stream
// @access  Private
router.post('/:id/end', protect, async (req, res) => {
  try {
    const liveStream = await LiveStream.findById(req.params.id);

    if (!liveStream) {
      return res.status(404).json({
        success: false,
        message: 'Stream not found'
      });
    }

    // Check if user owns the stream
    if (liveStream.streamer.toString() !== req.user.id) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized'
      });
    }

    // Calculate duration
    const endedAt = new Date();
    const duration = Math.floor((endedAt - liveStream.startedAt) / 1000);

    liveStream.status = 'ended';
    liveStream.endedAt = endedAt;
    liveStream.duration = duration;
    await liveStream.save();

    // Notify viewers
    const io = req.app.get('io');
    io.to(`stream_${liveStream._id}`).emit('stream_ended', {
      streamId: liveStream._id
    });

    res.json({
      success: true,
      message: 'Stream ended',
      duration
    });
  } catch (error) {
    console.error('End live stream error:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Server error'
    });
  }
});

// @route   POST /api/live/:id/join
// @desc    Join a live stream
// @access  Private
router.post('/:id/join', protect, async (req, res) => {
  try {
    const liveStream = await LiveStream.findById(req.params.id);

    if (!liveStream) {
      return res.status(404).json({
        success: false,
        message: 'Stream not found'
      });
    }

    if (liveStream.status !== 'live') {
      return res.status(400).json({
        success: false,
        message: 'Stream is not live'
      });
    }

    // Check if already joined
    const alreadyJoined = liveStream.viewers.some(
      v => v.user.toString() === req.user.id
    );

    if (!alreadyJoined) {
      liveStream.viewers.push({
        user: req.user.id,
        joinedAt: new Date()
      });
      liveStream.totalViewers += 1;
    }

    liveStream.viewerCount = liveStream.viewers.length;
    await liveStream.save();

    // Notify streamer
    const io = req.app.get('io');
    io.to(liveStream.streamer.toString()).emit('viewer_joined', {
      streamId: liveStream._id,
      viewer: {
        _id: req.user.id,
        name: req.user.name,
        photos: req.user.photos
      },
      viewerCount: liveStream.viewerCount
    });

    res.json({
      success: true,
      stream: liveStream
    });
  } catch (error) {
    console.error('Join stream error:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Server error'
    });
  }
});

// @route   POST /api/live/:id/leave
// @desc    Leave a live stream
// @access  Private
router.post('/:id/leave', protect, async (req, res) => {
  try {
    const liveStream = await LiveStream.findById(req.params.id);

    if (!liveStream) {
      return res.status(404).json({
        success: false,
        message: 'Stream not found'
      });
    }

    // Remove viewer
    liveStream.viewers = liveStream.viewers.filter(
      v => v.user.toString() !== req.user.id
    );
    liveStream.viewerCount = liveStream.viewers.length;
    await liveStream.save();

    // Notify streamer
    const io = req.app.get('io');
    io.to(liveStream.streamer.toString()).emit('viewer_left', {
      streamId: liveStream._id,
      viewerId: req.user.id,
      viewerCount: liveStream.viewerCount
    });

    res.json({
      success: true
    });
  } catch (error) {
    console.error('Leave stream error:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Server error'
    });
  }
});

// @route   POST /api/live/:id/comment
// @desc    Send comment in live stream
// @access  Private
router.post('/:id/comment', protect, async (req, res) => {
  try {
    const { text } = req.body;

    if (!text || text.trim().length === 0) {
      return res.status(400).json({
        success: false,
        message: 'Please provide comment text'
      });
    }

    const liveStream = await LiveStream.findById(req.params.id);

    if (!liveStream) {
      return res.status(404).json({
        success: false,
        message: 'Stream not found'
      });
    }

    if (liveStream.status !== 'live') {
      return res.status(400).json({
        success: false,
        message: 'Stream is not live'
      });
    }

    // Add comment
    const comment = {
      user: req.user.id,
      text: text.trim(),
      sentAt: new Date()
    };

    liveStream.comments.push(comment);
    await liveStream.save();

    // Populate user info
    await liveStream.populate('comments.user', 'name photos');

    // Broadcast comment to all viewers
    const io = req.app.get('io');
    io.to(`stream_${liveStream._id}`).emit('new_comment', {
      streamId: liveStream._id,
      comment: {
        ...comment,
        user: {
          _id: req.user.id,
          name: req.user.name,
          photos: req.user.photos
        }
      }
    });

    res.json({
      success: true,
      comment
    });
  } catch (error) {
    console.error('Send comment error:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Server error'
    });
  }
});

// @route   POST /api/live/:id/gift
// @desc    Send gift in live stream
// @access  Private
router.post('/:id/gift', protect, async (req, res) => {
  try {
    const { giftType, amount, message } = req.body;

    if (!giftType || !amount) {
      return res.status(400).json({
        success: false,
        message: 'Please provide gift type and amount'
      });
    }

    const liveStream = await LiveStream.findById(req.params.id);

    if (!liveStream) {
      return res.status(404).json({
        success: false,
        message: 'Stream not found'
      });
    }

    if (liveStream.status !== 'live') {
      return res.status(400).json({
        success: false,
        message: 'Stream is not live'
      });
    }

    // Add gift
    const gift = {
      sender: req.user.id,
      giftType,
      amount,
      message,
      sentAt: new Date()
    };

    liveStream.gifts.push(gift);
    liveStream.totalGifts += amount;
    await liveStream.save();

    // Notify streamer and viewers
    const io = req.app.get('io');
    io.to(`stream_${liveStream._id}`).emit('new_gift', {
      streamId: liveStream._id,
      gift: {
        ...gift,
        sender: {
          _id: req.user.id,
          name: req.user.name,
          photos: req.user.photos
        }
      }
    });

    res.json({
      success: true,
      gift
    });
  } catch (error) {
    console.error('Send gift error:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Server error'
    });
  }
});

// @route   GET /api/live/:id
// @desc    Get stream details
// @access  Private
router.get('/:id', protect, async (req, res) => {
  try {
    const liveStream = await LiveStream.findById(req.params id)
      .populate('streamer', 'name photos age city bio')
      .populate('viewers.user', 'name photos')
      .populate('gifts.sender', 'name photos');

    if (!liveStream) {
      return res.status(404).json({
        success: false,
        message: 'Stream not found'
      });
    }

    res.json({
      success: true,
      stream: liveStream
    });
  } catch (error) {
    console.error('Get stream details error:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Server error'
    });
  }
});

// @route   GET /api/live/trending/streamers
// @desc    Get trending streamers
// @access  Private
router.get('/trending/streamers', protect, async (req, res) => {
  try {
    const trendingStreamers = await LiveStream.getTrendingStreamers();

    // Populate user details
    const populatedStreamers = await User.populate(trendingStreamers, {
      path: '_id',
      select: 'name photos'
    });

    res.json({
      success: true,
      streamers: populatedStreamers
    });
  } catch (error) {
    console.error('Get trending streamers error:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Server error'
    });
  }
});

module.exports = router;
