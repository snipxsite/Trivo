const express = require('express');
const router = express.Router();
const User = require('../models/User');
const Match = require('../models/Match');
const { ChatRoom } = require('../models/Chat');
const { protect } = require('../middleware/auth');

// Generate unique chat room ID
const generateChatRoomId = (userId1, userId2) => {
  const sorted = [userId1, userId2].sort();
  return `chat_${sorted[0]}_${sorted[1]}`;
};

// @route   POST /api/matches/swipe
// @desc    Swipe right (like) or left (skip)
// @access  Private
router.post('/swipe', protect, async (req, res) => {
  try {
    const { targetUserId, action } = req.body; // action: 'like' or 'skip'

    if (!targetUserId || !action) {
      return res.status(400).json({
        success: false,
        message: 'Please provide targetUserId and action'
      });
    }

    if (targetUserId === req.user.id) {
      return res.status(400).json({
        success: false,
        message: 'Cannot swipe on yourself'
      });
    }

    const targetUser = await User.findById(targetUserId);
    if (!targetUser) {
      return res.status(404).json({
        success: false,
        message: 'Target user not found'
      });
    }

    // Check if already swiped
    let existingMatch = await Match.findMatch(req.user.id, targetUserId);

    if (existingMatch) {
      return res.status(400).json({
        success: false,
        message: 'Already swiped on this user'
      });
    }

    // Create match record
    if (action === 'like') {
      // Check if target user already liked current user (it's a match!)
      const reverseMatch = await Match.findOne({
        users: { $all: [targetUserId, req.user.id] },
        initiator: targetUserId,
        status: 'pending'
      });

      if (reverseMatch) {
        // IT'S A MATCH!
        reverseMatch.status = 'matched';
        reverseMatch.matchedAt = Date.now();
        reverseMatch.chatRoom = generateChatRoomId(req.user.id, targetUserId);
        await reverseMatch.save();

        // Create chat room
        await ChatRoom.create({
          roomId: reverseMatch.chatRoom,
          participants: [req.user.id, targetUserId],
          match: reverseMatch._id
        });

        // Update stats
        await User.findByIdAndUpdate(req.user.id, {
          $inc: { 'stats.likesGiven': 1, 'stats.matches': 1 }
        });
        await User.findByIdAndUpdate(targetUserId, {
          $inc: { 'stats.matches': 1 }
        });

        // Emit socket event for real-time notification
        const io = req.app.get('io');
        io.to(targetUserId.toString()).emit('new_match', {
          matchId: reverseMatch._id,
          user: {
            _id: req.user.id,
            name: req.user.name,
            photos: req.user.photos
          }
        });

        return res.json({
          success: true,
          isMatch: true,
          message: "It's a match!",
          match: reverseMatch
        });
      }

      // Create pending match (like)
      const newMatch = await Match.create({
        users: [req.user.id, targetUserId],
        initiator: req.user.id,
        status: 'pending'
      });

      // Update stats
      await User.findByIdAndUpdate(req.user.id, {
        $inc: { 'stats.likesGiven': 1 }
      });
      await User.findByIdAndUpdate(targetUserId, {
        $inc: { 'stats.likesReceived': 1 }
      });

      // Emit notification to target user
      const io = req.app.get('io');
      io.to(targetUserId.toString()).emit('new_like', {
        from: {
          _id: req.user.id,
          name: req.user.name,
          photos: req.user.photos
        }
      });

      return res.json({
        success: true,
        isMatch: false,
        message: 'Like sent successfully',
        match: newMatch
      });
    } else {
      // Skip - create match with status that indicates skip
      const newMatch = await Match.create({
        users: [req.user.id, targetUserId],
        initiator: req.user.id,
        status: 'unmatched',
        unmatchedBy: req.user.id
      });

      return res.json({
        success: true,
        isMatch: false,
        message: 'Skipped',
        match: newMatch
      });
    }
  } catch (error) {
    console.error('Swipe error:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Server error'
    });
  }
});

// @route   GET /api/matches
// @desc    Get all matches for current user
// @access  Private
router.get('/', protect, async (req, res) => {
  try {
    const matches = await Match.getUserMatches(req.user.id);

    // Format matches to show other user info
    const formattedMatches = matches.map(match => {
      const otherUser = match.users.find(
        u => u._id.toString() !== req.user.id
      );
      
      return {
        _id: match._id,
        user: otherUser,
        matchedAt: match.matchedAt,
        chatRoom: match.chatRoom,
        lastMessage: match.lastMessage,
        unreadCount: match.unreadCount?.get(req.user.id.toString()) || 0
      };
    });

    res.json({
      success: true,
      count: formattedMatches.length,
      matches: formattedMatches
    });
  } catch (error) {
    console.error('Get matches error:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Server error'
    });
  }
});

// @route   GET /api/matches/likes
// @desc    Get users who liked current user
// @access  Private
router.get('/likes', protect, async (req, res) => {
  try {
    const likes = await Match.find({
      users: req.user.id,
      initiator: { $ne: req.user.id },
      status: 'pending'
    }).populate('initiator', 'name photos age city');

    res.json({
      success: true,
      count: likes.length,
      likes: likes.map(like => ({
        _id: like._id,
        user: like.initiator,
        createdAt: like.createdAt
      }))
    });
  } catch (error) {
    console.error('Get likes error:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Server error'
    });
  }
});

// @route   GET /api/matches/:id
// @desc    Get single match details
// @access  Private
router.get('/:id', protect, async (req, res) => {
  try {
    const match = await Match.findById(req.params.id)
      .populate('users', 'name photos age bio city isOnline lastActive');

    if (!match) {
      return res.status(404).json({
        success: false,
        message: 'Match not found'
      });
    }

    // Check if user is part of this match
    if (!match.users.some(u => u._id.toString() === req.user.id)) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized'
      });
    }

    res.json({
      success: true,
      match
    });
  } catch (error) {
    console.error('Get match error:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Server error'
    });
  }
});

// @route   DELETE /api/matches/:id
// @desc    Unmatch a user
// @access  Private
router.delete('/:id', protect, async (req, res) => {
  try {
    const match = await Match.findById(req.params.id);

    if (!match) {
      return res.status(404).json({
        success: false,
        message: 'Match not found'
      });
    }

    // Check if user is part of this match
    if (!match.users.includes(req.user.id)) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized'
      });
    }

    match.status = 'unmatched';
    match.unmatchedBy = req.user.id;
    await match.save();

    // Delete chat room
    if (match.chatRoom) {
      await ChatRoom.findOneAndDelete({ roomId: match.chatRoom });
    }

    res.json({
      success: true,
      message: 'Unmatched successfully'
    });
  } catch (error) {
    console.error('Unmatch error:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Server error'
    });
  }
});

// @route   POST /api/matches/:id/superlike
// @desc    Send super like (premium feature)
// @access  Private
router.post('/:id/superlike', protect, async (req, res) => {
  try {
    // Check if premium user
    if (!req.user.isPremium) {
      return res.status(403).json({
        success: false,
        message: 'Super likes are a premium feature'
      });
    }

    const targetUserId = req.params.id;
    
    if (targetUserId === req.user.id) {
      return res.status(400).json({
        success: false,
        message: 'Cannot super like yourself'
      });
    }

    // Create or update match with super like
    let match = await Match.findMatch(req.user.id, targetUserId);

    if (match) {
      return res.status(400).json({
        success: false,
        message: 'Already interacted with this user'
      });
    }

    // Check if target user already liked current user
    const reverseMatch = await Match.findOne({
      users: { $all: [targetUserId, req.user.id] },
      initiator: targetUserId,
      status: 'pending'
    });

    if (reverseMatch) {
      // IT'S A MATCH with super like!
      reverseMatch.status = 'matched';
      reverseMatch.matchedAt = Date.now();
      reverseMatch.chatRoom = generateChatRoomId(req.user.id, targetUserId);
      reverseMatch.isSuperLike = true;
      await reverseMatch.save();

      // Create chat room
      await ChatRoom.create({
        roomId: reverseMatch.chatRoom,
        participants: [req.user.id, targetUserId],
        match: reverseMatch._id
      });

      // Emit notification
      const io = req.app.get('io');
      io.to(targetUserId.toString()).emit('super_match', {
        matchId: reverseMatch._id,
        user: {
          _id: req.user.id,
          name: req.user.name,
          photos: req.user.photos
        }
      });

      return res.json({
        success: true,
        isMatch: true,
        isSuperLike: true,
        message: "It's a super match!",
        match: reverseMatch
      });
    }

    // Create pending match with super like
    const newMatch = await Match.create({
      users: [req.user.id, targetUserId],
      initiator: req.user.id,
      status: 'pending',
      isSuperLike: true
    });

    // Emit notification
    const io = req.app.get('io');
    io.to(targetUserId.toString()).emit('new_superlike', {
      from: {
        _id: req.user.id,
        name: req.user.name,
        photos: req.user.photos
      }
    });

    res.json({
      success: true,
      isMatch: false,
      isSuperLike: true,
      message: 'Super like sent!',
      match: newMatch
    });
  } catch (error) {
    console.error('Super like error:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Server error'
    });
  }
});

module.exports = router;
